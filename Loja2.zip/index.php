<?php

header("X-XSS-Protection: 1; mode=block");
header("X-WebKit-CSP: policy");

session_start();
date_default_timezone_set('America/Sao_Paulo');

define('APP_ROOT', "https://".$_SERVER['HTTP_HOST']."/");

require_once 'app/helper/autoload.php';
require_once 'vendor/autoload.php';

use app\lib\System;
use app\lib\Model;

$System = new System();
$System->run();

$model = new Model();
$model->closeConnection();