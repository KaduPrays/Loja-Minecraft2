<?php

namespace app\lib;

class Config {

    /**
     * Dados de acesso ao banco de dados
     */
    const DBHOST = "142.4.208.192";
    const DBUSER = "patata_admin";
    const DBPASS = ";H4~,),SiZx3";
    const DBNAME = "patata_site";
    const DBCHAR = "utf8";

    /**
     * Dados de acesso ao painel administrativo
     */
    const ADMINUSER = "admin";
    const ADMINPASS = "Slowhosting2000";

    /**
     * Dados das gateways
     * MercadoPago, PayPal e BCash
     */
    const MERCADOPAGO_CLIENT = "8227464542370072";
    const MERCADOPAGO_SECRET = "Fo6Yuq6nFhDLsxyirDx6t4F2tHcOd8RU";

    const PAYPAL_EMAIL     = "guilherme";
    const PAYPAL_PASSWORD  = "";
    const PAYPAL_SIGNATURE = "";

    const BCASH_EMAIL = "";

    /**
     * Domínio que está hospedada
     */
    const MACHINE = 'redeflat.com';

    /**
     * Servidor de emails
     */
    const MAIL_SMTP = 'SMTP';
    const MAIL_USER = 'USER';
    const MAIL_PASS = 'PASS';
    const MAIL_PORT = 587;

    /**
     * Valor do pacote unban
     */
    const UNBAN_AMOUNT = 01;

    /**
     * Recurso para desenvolvedor
     */
    const SANDBOX = false;
}