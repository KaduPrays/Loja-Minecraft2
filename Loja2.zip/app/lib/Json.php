<?php

namespace app\lib;

Class Json {

    public static function response($data)
    {
        header('Content-type: application/json; charset=utf-8');
        return json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
    }
}