<?php 

namespace app\lib;

use PDO;

class Model extends Config {

    private $con;

    public function __construct() {
        try {
            $this->con = new PDO("mysql:host=".self::DBHOST.";dbname=".self::DBNAME, self::DBUSER, self::DBPASS, array(PDO::ATTR_PERSISTENT => true));
            $this->con->exec("set names ".self::DBCHAR);
            $this->con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (\PDOException $e) {
            header("HTTP/1.0 404 Not Found");
            define('ERROR', "Erro na conexão: <br>".$e->getMessage());
            include("app/content/shared/404_error.phtml");
            exit(); 
        }
    }

    public function set($host, $user, $pass, $db) {
        try {
            $this->con = new PDO("mysql:host=".$host.";dbname=".$db, $user, $pass);
            $this->con->exec("set names utf8");
        } catch (\PDOException $e) {
            header("HTTP/1.0 404 Not Found");
            define('ERROR', "Erro na conexão: <br>".$e->getMessage());
            include("app/content/shared/404_error.phtml");
            exit();
        }
    }

    public function getConnection() {
        return $this->con;
    }

    public function getNewConnection() {
        return $this->con;
    }

    public function closeConnection() {
        $this->con = null;
    }

}