<?php

namespace app\lib;

class Security
{

    public static function connection()
    {
        return stristr($_SERVER['HTTP_REFERER'], Config::MACHINE);
    }

}