<?php

namespace app\lib;

class Router {

    protected $routers = array('site'  => 'site');

    private $urlBase = APP_ROOT;

    protected $routerOnRaiz = 'site';

    protected $onRaiz = true;
}