<?php

namespace app\api;

use app\lib\Config;
use app\lib\Json;
use app\lib\Model;
use app\lib\Security;
use PDO;

class Admin
{

    private $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    public function isLogged()
    {
        return isset($_SESSION['WebAdminLogin']);
    }

    public function logout()
    {
        unset($_SESSION['WebAdminLogin']);
        return header('Location: /admin');
    }

    public function getEarn()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_PAID`=?");
        $stmt->execute([1]);
        $soma = $stmt->fetchObject()->soma;
        return number_format($soma, 2, ',', '.');
    }

    public function getNet()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_MONTH`=? AND `transaction_PAID`=?");
        $stmt->execute([date("m/Y"), 1]);
        return $stmt->fetchObject()->soma;
    }

    public function getGross()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT SUM(`transaction_GROSS`) as soma FROM `website_transactions` WHERE `transaction_MONTH`=? AND `transaction_PAID`=?");
        $stmt->execute([date("m/Y"), 1]);
        return $stmt->fetchObject()->soma;
    }

    public function getSales()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT * FROM `website_transactions` WHERE `transaction_PAID`=?");
        $stmt->execute([1]);
        return number_format($stmt->rowCount(), 0, '', '.');
    }

    public function getEarnMonth()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_PAID`=? AND `transaction_MONTH`=?");
        $stmt->execute([1, date("m/Y")]);
        $soma = $stmt->fetchObject()->soma  - $this->getEarnsBlocked();
        return number_format($soma, 2, ',', '.');
    }

    public function getEarnMonthWithout()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_PAID`=? AND `transaction_MONTH`=?");
        $stmt->execute([1, date("m/Y")]);
        $soma = $stmt->fetchObject()->soma - $this->getWithout();
        return number_format($soma, 2, ',', '.');
    }

    public function getPendingMonth()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_STATUS`=? AND `transaction_MONTH`=?");
        $stmt->execute(['pending', date("m/Y")]);
        $soma = $stmt->fetchObject()->soma;
        return number_format($soma, 2, ',', '.');
    }

    public function getWithout()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT SUM(`capital_AMOUNT`) as soma FROM `website_capital_history` WHERE `capital_DATE` LIKE ?");
        $stmt->execute(['%'.date("Y-m").'%']);
        return $stmt->fetchObject()->soma;
    }

    public function getSalesMonth()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT * FROM `website_transactions` WHERE `transaction_PAID`=? AND `transaction_MONTH`=?");
        $stmt->execute([1, date("m/Y")]);
        return number_format($stmt->rowCount(), 0, '', '.');
    }

    public function getChargeMonth()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_transactions` WHERE `transaction_STATUS` = ? AND transaction_MONTH = ?");
        $stmt->execute(['charged_back', date("m/Y")]);
        return $stmt->rowCount();
    }

    public function getChargeAmount()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT SUM(transaction_AMOUNT) as soma FROM `website_transactions` WHERE `transaction_STATUS` = ?");
        $stmt->execute(['in_mediation']);
        return $stmt->fetchObject()->soma;
    }

    public function getSalesCalc()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT * FROM `website_transactions` WHERE `transaction_MONTH`=? AND `transaction_PAID`=?");
        $stmt->execute([date("m/Y"), 1]);

        $stmt2 =  $this->model->getConnection()->prepare("SELECT * FROM `website_transactions` WHERE `transaction_MONTH`=? AND `transaction_PAID`=?");
        $stmt2->execute([date('m/Y', strtotime('-1 months', strtotime(date('Y-m-d')))), 1]);

        $atual = $stmt->rowCount();
        $ant   = $stmt2->rowCount();
        $x = ($atual * 100) / ( $ant == 0 ? 1 : $ant );
        return $this->posneg($x);
    }

    public function getEarnsCalc()
    {
        $stmt =  $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_MONTH`=? AND `transaction_PAID`=?");
        $stmt->execute([date("m/Y"), 1]);

        $stmt2 =  $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_MONTH`=? AND `transaction_PAID`=?");
        $stmt2->execute([date('m/Y', strtotime('-1 months', strtotime(date('Y-m-d')))), 1]);

        $atual = $stmt->fetchObject()->soma - $this->getEarnsBlocked();
        $ant   = $stmt2->fetchObject()->soma;
        $x = ($atual * 100) / ( $ant == 0 ? 1 : $ant );
        return $this->posneg($x);
    }

    public function getEarnsBlocked()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_DATE` >= ? AND 
                                                                                                                                             `transaction_DATE` <= ? AND 
                                                                                                                                             `transaction_PAID` = ? AND 
                                                                                                                                             `transaction_GATEWAY` = ?");

        $start = date("Y-m-d");
        $end   = date("Y-m-d", strtotime($start." -14 days"));

        $stmt->execute([$end, $start, 1, "MercadoPago"]);
        return $stmt->fetchObject()->soma;
    }

    public function lastTransactions()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_transactions` ORDER BY `transaction_DATE` DESC LIMIT 10");
        $stmt->execute();
        if($stmt->rowCount() == 0) { return "<h5 class='text-muted' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%)'>Não há transações</h5>"; }
        $fetch = $stmt->fetchAll(PDO::FETCH_OBJ);
        $transactions = "";
        foreach ($fetch as $rs)
        {

            $amount = "R$".number_format($rs->transaction_AMOUNT, 2, ',', '.');
            $date   = date("d/m/Y", strtotime($rs->transaction_DATE));
            if($date == date("d/m/Y")) {
                $date = "Hoje";
            }

            $transactions .= "<div class=\"transaction\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            <div class=\"code\">
                                {$rs->transaction_CODE}
                            </div>
                        </div>
                        <div class=\"col-md-3\">
                            <div class=\"status\">
                                {$this->status($rs->transaction_STATUS)}
                            </div>
                        </div>
                        <div class=\"col-md-3\">
                            <button class=\"tr-modal-open\" id=\"{$rs->transaction_REFERENCE}\">detalhes</button>
                        </div>
                    </div>
                </div>
                <div class=\"tr-modal tr-open-{$rs->transaction_REFERENCE}\">
                    <div class=\"tr-title\">
                        Dados da transação
                    </div>
                    <button class=\"tr-close\">
                        <i class=\"ion-ios-close-empty\"></i>
                    </button>
                    <br>
                    <div class=\"tr-body\">
                        <p>
                            Transação:
                            <small class=\"float-right\">{$rs->transaction_CODE}</small>
                        </p>
                        <p>
                            Gateway:
                            <span class=\"float-right\">{$rs->transaction_GATEWAY}</span>
                        </p>
                        <p>
                            Valor:
                            <span class=\"float-right\">{$amount}</span>
                        </p>
                        <p>
                            Data de compra:
                            <span class=\"float-right\">{$date}</span>
                        </p>
                        <p>
                            Comprador:
                            <span class=\"float-right\">{$rs->transaction_USERNAME}</span>
                        </p>
                        <p>
                            Status de compra:
                            <span class=\"float-right\">{$this->status($rs->transaction_STATUS)}</span>
                        </p>
                    </div>
                </div>";
        }
        return $transactions;
    }

    public function getHours()
    {
        $arry = array();
        for ($i=0; $i <= 23; $i++) {
            array_push($arry, $i);
        }
        $labels = "";
        foreach ($arry as $label) {
            $labels.="'{$label}hrs' ,";
        }
        return substr($labels, 0, -1);
    }

    public function getLastDays()
    {
        $arry = array();
        for ($i=0; $i <= 7; $i++) {
            $date = date("Y-m-d");
            $date = strtotime($date);
            $date = strtotime("-$i days", $date);
            $date = date("Y-m-d", $date);
            $date = explode("-", $date);
            $str  = "{$date[2]}/{$date[1]}";
            array_unshift($arry, $str);
        }
        array_reverse($arry);
        $json = json_encode($arry);
        $json = json_decode($json);
        $labels = "";
        foreach ($json as $label) {
            $labels.="'$label',";
        }
        return substr($labels, 0, -1);
    }

    public function get30Days()
    {
        $arry = array();
        for ($i=0; $i <= 30; $i++) {
            $date = date("Y-m-d");
            $date = strtotime($date);
            $date = strtotime("-$i days", $date);
            $date = date("Y-m-d", $date);
            $date = explode("-", $date);
            $str  = "{$date[2]}/{$date[1]}";
            array_unshift($arry, $str);
        }
        array_reverse($arry);
        $json = json_encode($arry);
        $json = json_decode($json);
        $labels = "";
        foreach ($json as $label) {
            $labels.="'$label',";
        }
        return substr($labels, 0, -1);
    }

    public function get7LastSales()
    {
        $arry = array();
        for ($i=0; $i <= 7; $i++) {
            $date = date("Y-m-d");
            $date = strtotime($date);
            $date = strtotime("-$i days", $date);
            $date = date("Y-m-d", $date);
            array_unshift($arry, $date);
        }
        array_reverse($arry);
        $json = json_encode($arry);
        $json = json_decode($json);
        $labels = "";
        foreach ($json as $label) {
            $sales = $this->getSalesInDate($label);
            $labels.="'$sales',";
        }
        return substr($labels, 0, -1);
    }

    public function getLastEarnsInHour()
    {
        $arry = array();
        for ($i=0; $i <= 23; $i++) {
            array_push($arry, $i);
        }
        $labels = "";
        foreach ($arry as $label) {
            $sales = $this->getEarnInHour($label);
            $labels.="'$sales',";
        }
        return substr($labels, 0, -1);
    }

    public function getLastEarnsInHour2()
    {
        $arry = array();
        for ($i=0; $i <= 23; $i++) {
            array_push($arry, $i);
        }
        $labels = "";
        foreach ($arry as $label) {
            $sales = $this->getEarnInHour2($label);
            $labels.="'$sales',";
        }
        return substr($labels, 0, -1);
    }

    private function getEarnInHour($hour)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_HOUR`=? AND `transaction_DATE`=? AND `transaction_PAID`=?");
        $stmt->execute([$hour, date("Y-m-d"), 1]);
        return $stmt->fetchObject()->soma;
    }

    private function getEarnInHour2($hour)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT SUM(`transaction_GROSS`) as soma FROM `website_transactions` WHERE `transaction_HOUR`=? AND `transaction_DATE`=? AND `transaction_PAID`=?");
        $stmt->execute([$hour, date("Y-m-d"), 1]);
        return $stmt->fetchObject()->soma;
    }

    private function getSalesInDate($str)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_transactions` WHERE `transaction_DATE`=? AND `transaction_PAID`=?");
        $stmt->execute([$str, 1]);
        return $stmt->rowCount();
    }

    public function get7LastEarns()
    {
        $arry = array();
        for ($i=0; $i <= 7; $i++) {
            $date = date("Y-m-d");
            $date = strtotime($date);
            $date = strtotime("-$i days", $date);
            $date = date("Y-m-d", $date);
            array_unshift($arry, $date);
        }
        array_reverse($arry);
        $json = json_encode($arry);
        $json = json_decode($json);
        $labels = "";
        foreach ($json as $label) {
            $sales = $this->getEarnsInDate($label);
            $labels.="'$sales',";
        }
        return substr($labels, 0, -1);
    }

    public function get7LastEarns2()
    {
        $arry = array();
        for ($i=0; $i <= 7; $i++) {
            $date = date("Y-m-d");
            $date = strtotime($date);
            $date = strtotime("-$i days", $date);
            $date = date("Y-m-d", $date);
            array_unshift($arry, $date);
        }
        array_reverse($arry);
        $json = json_encode($arry);
        $json = json_decode($json);
        $labels = "";
        foreach ($json as $label) {
            $sales = $this->getEarnsInDate2($label);
            $labels.="'$sales',";
        }
        return substr($labels, 0, -1);
    }

    public function get30LastEarns()
    {
        $arry = array();
        for ($i=0; $i <= 30; $i++) {
            $date = date("Y-m-d");
            $date = strtotime($date);
            $date = strtotime("-$i days", $date);
            $date = date("Y-m-d", $date);
            array_unshift($arry, $date);
        }
        array_reverse($arry);
        $json = json_encode($arry);
        $json = json_decode($json);
        $labels = "";
        foreach ($json as $label) {
            $sales = $this->getEarnsInDate($label);
            $labels.="'$sales',";
        }
        return substr($labels, 0, -1);
    }

    public function get30LastEarns2()
    {
        $arry = array();
        for ($i=0; $i <= 30; $i++) {
            $date = date("Y-m-d");
            $date = strtotime($date);
            $date = strtotime("-$i days", $date);
            $date = date("Y-m-d", $date);
            array_unshift($arry, $date);
        }
        array_reverse($arry);
        $json = json_encode($arry);
        $json = json_decode($json);
        $labels = "";
        foreach ($json as $label) {
            $sales = $this->getEarnsInDate2($label);
            $labels.="'$sales',";
        }
        return substr($labels, 0, -1);
    }

    private function getEarnsInDate($str)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT SUM(`transaction_AMOUNT`) as soma FROM `website_transactions` WHERE `transaction_DATE`=? AND `transaction_PAID`=?");
        $stmt->execute([$str, 1]);
        return $stmt->fetchObject()->soma;
    }

    private function getEarnsInDate2($str)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT SUM(`transaction_GROSS`) as soma FROM `website_transactions` WHERE `transaction_DATE`=? AND `transaction_PAID`=?");
        $stmt->execute([$str, 1]);
        return $stmt->fetchObject()->soma;
    }

    private function status($str)
    {
        $status = [
            'pending'      => "<font color='#fbc02d'>Pendente</font>",
            'approved'     => "<font color='#9ccc65'>Pago</font>",
            'in_process'   => "<font color='#42a5f5'>Em análise</font>",
            'in_mediation' => "<font color='#f9a825'>Em disputa</font>",
            'rejected'     => "<font color='#f44336'>Recusado</font>",
            'cancelled'    => "<font color='#f44336'>Cancelado</font>",
            'charged_back' => '<font color=\'#f44336\'>Devolvido</font>',
            'refunded'     => '<font color=\'#f44336\'>Devolvido</font>',
            'Canceled_Reversal' => 'Pago',
            'Completed'         => 'Pago',
            'Created'           => 'Aguardando pagamento',
            'Denied'            => 'Recusado',
            'Expired'           => 'Expirado',
            'Failed'            => 'Falha',
            'Pending'           => 'Aguardando pagamento',
            'Refunded'          => 'Devolvido',
            'Reversed'          => 'Em disputa',
            'Voided'            => 'Em análise',
            'Processed'         => 'Aguardando pagamento'
        ];
        return $status[$str];
    }

    public function compare()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT 
                                                                  SUM(`transaction_AMOUNT`) as net, 
                                                                  SUM(`transaction_GROSS`) as gross,
                                                                  COUNT(*) as sales
                                                                FROM `website_transactions` 
                                                                WHERE `transaction_DATE` BETWEEN ? AND ?
                                                                AND `transaction_PAID`=?");
        $stmt->execute([$_POST['d1'], $_POST['d2'], 1]);

        $rs = $stmt->fetchObject();

        $html = "<br>
                <h5>Resultado:</h5>
                <p class=\"m-1\">Ganho líquido: <span class=\"float-right\">{$rs->net}</span></p>
                <p class=\"m-1\">Ganho grosso: <span class=\"float-right\">{$rs->gross}</span></p>
                <p class=\"m-1\">Vendas: <span class=\"float-right\">{$rs->sales}</span></p>";

        return $html;
    }

    private function posneg($i)
    {
        $arr =round($i * 100) / 100;
        if($i < 0) { return "<span style='color: #f44336'>-{$arr}%</span>"; }
        if($i == 0) { return "<span style='color: #757575'>-/- </span>"; }
        return "<span style='color: #8bc34a'>+{$arr}%</span>";
    }

    public function transactions()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_transactions` ORDER BY `transaction_DATE` DESC");
        $stmt->execute();
        if($stmt->rowCount() == 0) { return ""; }
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $return = "";
        foreach ($fetch as $rs)
        {
            $amount  = "R$".number_format($rs->transaction_AMOUNT, 2, ',', '.');
            $amount2 = "R$".number_format($rs->transaction_GROSS, 2, ',', '.');
            $taxa    = "R$".number_format($rs->transaction_GROSS - $rs->transaction_AMOUNT, 2, ',', '.');
            $return .= "<tr>
                            <th scope=\"row\">{$rs->transaction_DATE}</th>
                            <td>{$rs->transaction_CODE}</td>
                            <td>{$rs->transaction_USERNAME}</td>
                            <td>{$rs->transaction_CUPOM}</td>
                            <td><button class='btn btn-primary btn-sm' data-toggle=\"modal\" data-target=\"#md-{$rs->transaction_REFERENCE}\" >ver</button></td>
                            <td>{$amount}</td>
                            <td>{$amount2}</td>
                            <td>{$taxa}</td>
                            <td>{$this->status($rs->transaction_STATUS)}</td>
                            <div class=\"modal fade\" id=\"md-{$rs->transaction_REFERENCE}\" tabindex=\"-1\" role=\"dialog\">
                                <div class=\"modal-dialog\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <div class=\"modal-header\">
                                            <h5 class=\"modal-title\">Itens do carrinho</h5>
                                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                                                <span aria-hidden=\"true\">&times;</span>
                                            </button>
                                        </div>
                                        <div class=\"modal-body\">
                                            <ul class=\"cart-itens\">
                                                {$this->productsli($rs->transaction_REFERENCE)}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </tr>";
        }
        return $return;
    }

    private function productsli($reference)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM website_references WHERE reference_ID=?");
        $stmt->execute([$reference]);
        $reference = $stmt->fetchObject()->reference_PACKAGES;
        $reference = explode(";", $reference);
        $li = "";
        foreach ($reference as $rs)
        {
            $info = explode(":", $rs);
            if($info[0] == 'unban')
            {
                $li .= "<li>Unban <span>Global</span></li>";
            }else{
                $info = $this->getInfo($info[0]);
                $li .= "<li>{$info['name']} <span class='float-right'>{$info['server']}</span></li>";
            }
        }
        return $li;
    }

    private function getInfo($package)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM website_packages WHERE package_ID=?");
        $stmt->execute([$package]);
        $fetch = $stmt->fetchObject();

        $name   = $fetch->package_NAME;
        $server = $fetch->package_SERVER;

        $stmt = $this->model->getConnection()->prepare("SELECT * FROM website_servers WHERE server_ID = ?");
        $stmt->execute([$server]);
        $server = $stmt->fetchObject()->server_NAME;

        return [
            'name'   => $name,
            'server' => $server
        ];
    }
}