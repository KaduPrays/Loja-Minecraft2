<?php

namespace app\api;

use app\lib\Config;
use app\lib\Model;
use app\lib\Json;
use PHPMailer\PHPMailer\PHPMailer;

class Checkout {

    private $pdo, $cart, $mp, $mail, $cupom, $paypal, $bcash;

    public function __construct() {
        $model           = new Model();
        $this->cupom     = new Cupom();
        $this->cart      = new Cart();
        $this->mp        = new \MP(Config::MERCADOPAGO_CLIENT, Config::MERCADOPAGO_SECRET);
        $this->paypal    = new PayPal();
        $this->bcash     = new BCash();
        $this->mail      = new PHPMailer();
        $this->pdo       = $model->getConnection();
    }

    public function run() {
        if((empty($_POST['nickname']))) { return Json::response(['response'=>'error', 'message'=>'Nada enviado']);  }

        $nickname = $_POST['nickname'];
        $gateway  = $_POST['gateway'];
        $price    = $this->cart->totalAmount();

        $reference = $this->addReference($this->cart->listPackages(), $nickname);
        $custom = $reference;

        if(isset($_SESSION['WebStoreDiscount'])) {
            $price  = $this->cart->totalAmount() - $_SESSION['WebStoreDiscount'];
            $cupom = @$_SESSION['WebCupom'];
            $custom = "{$reference};{$cupom}";
            if(isset($_SESSION['WebCupom'])) {
                $custom = "{$reference};{$cupom}";
            }
        }

        unset($_SESSION['WebCart']);
        unset($_SESSION['WebStoreDiscount']);
        unset($_SESSION['WebCupom']);

        if($gateway == "mercadopago")
        {
            $item = [
                "title" => "Compras de {$nickname}",
                "quantity" => 1,
                "currency_id" => "BRL",
                "unit_price" => (double) $price,
                "picture_url" => "https://www.mercadopago.com/org-img/MP3/home/logomp3.gif"
            ];

            $items = [ $item ];

            $backUrls = array("success" => APP_ROOT."loja", "failure" => APP_ROOT."loja", "pending" => APP_ROOT."loja");

            $preference_data = [
                "items" => $items,
                "back_urls" => $backUrls,
                "auto_return" => "all",
                "notification_url" => APP_ROOT."loja/notification",
                "external_reference" => $custom
            ];

            $preference = $this->mp->create_preference($preference_data);

            $url = $preference['response']['init_point'];
            unset($_SESSION['WebStoreDiscount']);
            return Json::response(
                [
                    'response' => 'ok',
                    'url' => $url
                ]
            );
        }
        if($gateway == "paypal")
        {
            return $this->paypal->setCheckout(
                "Compras de {$nickname}",
                "StringMC.",
                1,
                (double) $price,
                $reference,
                [
                    'return' => APP_ROOT.'loja/dopaypal',
                    'cancel' => APP_ROOT
                ]
            );
        }
        if($gateway == "bcash")
        {
            return $this->bcash->checkout(
                [
                   'reference'     => $reference,
                    'description'  => "Compras de {$nickname}",
                    'quantity'     => 1,
                    'amount'       => (double) $price,
                    'return'       => APP_ROOT.'loja',
                    'notification' => APP_ROOT.'loja/notification',
                    'custom'       => $reference
                ]
            );
        }
    }

    public function receive() {
        if(!isset($_POST)) { return Json::response([ 'response' => 'error', 'message' => 'Nada enviado' ]); }
        if ($_GET['topic'] == 'payment') {
            $payment_info = $this->mp->get_payment_info($_GET['id']);
            if ($payment_info["status"] == 200) {
                $data = $payment_info['response']['collection'];

                $code      = $data['id'];
                $status    = $data['status'];
                $amount    = $data['net_received_amount'];
                $gross     = $data['transaction_amount'];
                $reference = $data['external_reference'];
                $cupom = "";

                if(strpos($reference, ";")) {
                    $extra = explode(";", $reference);
                    $reference = $extra[0];
                    $cupom = $extra[1];
                }

                $nickname = $this->getUsernameReference($reference);
                $paid = ($status == 'approved') ? 1 : 0;

                $this->saveTransaction($code, "MercadoPago", $nickname, $reference, $amount, $gross, $status, $paid, $cupom);

                if($status == "approved") {
                    $this->addToHot($reference);
                    $this->addToChange($reference);
                }

                return "ok";
            }
        }
        if(isset($_POST['id_transacao'])) {
            // action
            return "ok";
        }

        $paypal    = $this->paypal->notify();

        $reference = $paypal->reference;
        $cupom = "";

        if(strpos($reference, ";")) {
            $extra = explode(";", $reference);
            $reference = $extra[0];
            $cupom = $extra[1];
        }

        $nickname = $this->getUsernameReference($reference);

        $this->saveTransaction($paypal->id, "PayPal", $nickname, $reference, $paypal->amount, $paypal->gross, $paypal->status, $paypal->paid, $cupom);

        if($paypal->status == "Completed")
        {
            $this->addToHot($reference);
            $this->addToChange($reference);
        }

        return "ok";
    }

    private function addToChange($reference)
    {
        $nickname = $this->getUsernameReference($reference);
        $products = $this->getProductsReferece($reference);

        $array = explode(";", $products);
        foreach ($array as $r) {
            $extra = explode(":", $r);
            $product = $extra[0];
            $server  = $extra[1];

            if($server != 0) {
                $stmt = $this->pdo->prepare("INSERT INTO `website_charge`(`charge_USERNAME`, `charge_COMMAND`, `charge_SERVER`, `charge_ONLINE`) VALUES (?, ?, ?, ?)");
                $stmt->execute([$nickname, $this->getCommands($product, $nickname), $server, 1]);
            }else{
                if($product == 'unban')
                {
                    $stmt = $this->pdo->prepare("INSERT INTO `website_charge`(`charge_USERNAME`, `charge_COMMAND`, `charge_SERVER`, `charge_ONLINE`) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$nickname, str_replace("{player}", $nickname, "unban {player}"), 0, 0]);
                }else{
                    $stmt = $this->pdo->prepare("INSERT INTO `website_charge`(`charge_USERNAME`, `charge_COMMAND`, `charge_SERVER`, `charge_ONLINE`) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$nickname, $this->getCommands($product, $nickname), 0, 1]);
                }
            }
        }
    }

    private function addToHot($reference)
    {
        $products = $this->getProductsReferece($reference);
        $array = explode(";", $products);
        foreach ($array as $r) {
            $extra = explode(":", $r);
            $product = $extra[0];
            $stmt = $this->pdo->prepare("SELECT * FROM `website_hot` WHERE `hot_PACKAGE`=? AND `hot_MONTH`=?");
            $stmt->execute([$product, date("m/Y")]);
            $fetch = $stmt->fetchObject();
            if($stmt->rowCount() > 0) {
                $adicionar = $fetch->hot_SALES + 1;
                $update = $this->pdo->prepare("UPDATE `website_hot` SET `hot_SALES`=? WHERE `hot_PACKAGE`=? AND `hot_MONTH`=?");
                $update->execute([$adicionar, $product, date("m/Y")]);
            }else{
                $insert = $this->pdo->prepare("INSERT INTO `website_hot`(`hot_PACKAGE`, `hot_MONTH`, `hot_SALES`) VALUES (?, ?, ?)");
                $insert->execute([$product, date("m/Y"), 1]);
            }
        }
    }

    private function addReference($packages, $username)
    {
        $save = "";
        foreach ($packages as $indice => $package) {
            $save .= "$indice;";
        }
        $save = substr($save, 0, -1);
        $stmt = $this->pdo->prepare("INSERT INTO `website_references`(`reference_USERNAME`, `reference_PACKAGES`) VALUES (?, ?)");
        $stmt->execute([$username, $save]);
        return $this->pdo->lastInsertId();
    }

    private function getUsernameReference($reference)
    {
        $stmt = $this->pdo->prepare("SELECT `reference_USERNAME` FROM `website_references` WHERE `reference_ID`=?");
        $stmt->execute([$reference]);
        return $stmt->fetchObject()->reference_USERNAME;
    }

    private function getProductsReferece($reference)
    {
        $stmt = $this->pdo->prepare("SELECT `reference_PACKAGES` FROM `website_references` WHERE `reference_ID`=?");
        $stmt->execute([$reference]);
        return $stmt->fetchObject()->reference_PACKAGES;
    }

    private function saveTransaction($code, $gateway, $nickname, $reference, $amount, $gross, $status, $paid, $cupom)
    {
        $stmtV = $this->pdo->prepare("SELECT `transaction_CODE` FROM `website_transactions` WHERE `transaction_CODE` = ?");
        $stmtV->execute([$code]);
        if($stmtV->rowCount() > 0) {
            $stmtU = $this->pdo->prepare("UPDATE `website_transactions` SET `transaction_STATUS`=?,`transaction_PAID`=? WHERE `transaction_CODE`=?");
            return $stmtU->execute([$status, $paid, $code]);
        }
        $stmtI = $this->pdo->prepare("INSERT INTO `website_transactions`(`transaction_CODE`, `transaction_GATEWAY`, `transaction_USERNAME`, `transaction_REFERENCE`, `transaction_AMOUNT`, `transaction_GROSS`, `transaction_CUPOM`, `transaction_DATE`, `transaction_MONTH`, `transaction_HOUR`, `transaction_STATUS`, `transaction_PAID`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        return $stmtI->execute([$code, $gateway, $nickname, $reference, $amount, $gross, $cupom, date("Y-m-d"), date("m/Y"), date('H'), $status, $paid]);
    }

    private function getCommands($package, $nickname)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM `website_packages` WHERE `package_ID`=?");
        $stmt->execute([$package]);
        return str_replace("{player}", $nickname, $stmt->fetchObject()->package_COMMANDS);
    }

    private function addChargeback($code, $username, $amount, $reference, $status)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM `website_chargebacks` WHERE `chargeback_CODE` = ?");
        $stmt->execute([$code]);
        if($stmt->rowCount() == 1)
        {
            $stmt = $this->pdo->prepare("INSERT INTO `website_chargebacks`(`chargeback_CODE`, `chargeback_USERNAME`, `chargeback_AMOUNT`, `chargeback_REFERENCE`, `chargeback_STATUS`) VALUES (?, ?, ?, ?, ?)");
            return $stmt->execute([$code, $username, $amount, $reference, $status]);
        }else{
            $stmt = $this->pdo->prepare("UPDATE `website_chargebacks` SET `chargeback_STATUS`=? WHERE `chargeback_CODE`=?");
            return $stmt->execute([$status, $code]);
        }
    }
}