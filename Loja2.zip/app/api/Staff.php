<?php

namespace app\api;

use app\lib\Json;
use app\lib\Model;
use app\lib\Security;

class Staff
{

    private $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    public function add()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        if(empty($_POST['username']) || empty($_POST['group'])) { return Json::response(['response' => 'error', 'message' => 'Preencha os dados do novo membro']); }
        $stmt = $this->model->getConnection()->prepare("INSERT INTO `website_staff`(`staff_USERNAME`, `staff_TWITTER`, `staff_GROUP`) VALUES (?, ?, ?)");
        $stmt->execute([$_POST['username'], $_POST['twitter'], $_POST['group']]);
        return Json::response(['response' => 'ok', 'messsage' => $_POST['username'].' adicionado ao grupo '.$_POST['group']]);
    }

    public function count()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_staff`");
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function delete()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        $stmt = $this->model->getConnection()->prepare("DELETE FROM `website_staff` WHERE `staff_ID`=?");
        $stmt->execute([$_POST['id']]);
        return Json::response(['response' => 'ok']);
    }

    public function listall()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_staff` ORDER BY `staff_ID` DESC");
        $stmt->execute();
        if($stmt->rowCount() == 0) { return "<h5 class='text-muted' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%)'>Não há membros</h5>"; }
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $staff = "";
        foreach ($fetch as $rs) {
            $staff .= "<div class=\"feed feed-{$rs->staff_ID}\">
                            <div class=\"row\">
                                <div class=\"col-md-4\">
                                    <div class=\"name mid\">
                                        {$rs->staff_USERNAME}
                                    </div>
                                </div>
                                <div class=\"col-md-4\">
                                    <div class=\"name mid\">
                                        {$rs->staff_GROUP}
                                    </div>
                                </div>
                                <div class=\"col-md-4\">
                                    <button class=\"tr-modal-open\" id=\"{$rs->staff_ID}\">detalhes</button>
                                </div>
                            </div>
                        </div>
                        <div class=\"tr-modal tr-open-{$rs->staff_ID}\">
                            <div class=\"tr-title\">
                                Informações da notícia
                            </div>
                            <button class=\"tr-close\">
                                <i class=\"ion-ios-close-empty\"></i>
                            </button>
                            <br>
                            <div class=\"tr-body\">
                                <p>
                                    Usuário:
                                    <span class=\"float-right\">{$rs->staff_USERNAME}</span>
                                </p>
                                <p>
                                    Grupo:
                                    <span class=\"float-right\">{$rs->staff_GROUP}</span>
                                </p>
                                <br>
                                <p>
                                    Deletar?
                                    <a href=\"javascript:void(0)\" class=\"float-right del-staff\" style=\"color: red\" id=\"{$rs->staff_ID}\">
                                        Sim
                                    </a>
                                </p>
                            </div>
                        </div>";
        }
        return $staff;
    }

    public function category($group)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_staff` WHERE `staff_GROUP`=?");
        $stmt->execute([$group]);
        if($stmt->rowCount() == 0) { return "<h5 class='col-md-12'>Não há membros neste cargo</h5>"; }
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $r = "";
        foreach ($fetch as $rs) {
            $twitter = "";
            if($rs->staff_TWITTER != "") {
                $twitter = "<div class=\"informations\">
                                <div class=\"mid\">
                                    <div class=\"title\">Siga-me</div>
                                    <button onclick=\"goTo('https://twitter.com/{$rs->staff_TWITTER}', true);\"><i class=\"ion-social-twitter\"></i></button>
                                </div>
                            </div>";
            }
            $r.="<div class=\"col-md-3\">
                        <div class=\"member\">
                            <img class=\"img-fluid\" src=\"https://minotar.net/helm/{$rs->staff_USERNAME}/200.png\">
                            <div class=\"name\">{$rs->staff_USERNAME}</div>
                            {$twitter}
                        </div>
                    </div>";
        }
        return $r;
    }

}