<?php

namespace app\api;

use app\lib\Config;

class PayPal {

    private $sandbox, $ppEmail, $ppPswd, $ppSignature;

    public function __construct() {
        date_default_timezone_set('America/Sao_Paulo');
        $this->sandbox = Config::SANDBOX;
        $this->ppEmail = Config::PAYPAL_EMAIL;
        $this->ppPswd  = Config::PAYPAL_PASSWORD;
        $this->ppSignature = Config::PAYPAL_SIGNATURE;
    }

    public function setCheckout($name, $description, $quantity, $amount, $reference, $return) {
        $requestNvp = array(
            'USER'      => $this->ppEmail,
            'PWD'       => $this->ppPswd,
            'SIGNATURE' => $this->ppSignature,

            'VERSION' => '204.0',
            'METHOD'  => 'SetExpressCheckout',

            'LOCALECODE' => 'BR',
            'LANDINGPAGE' => 'Billing',

            'PAYMENTREQUEST_0_PAYMENTACTION' => 'Sale',
            'PAYMENTREQUEST_0_AMT'           => $amount,
            'PAYMENTREQUEST_0_CURRENCYCODE'  => 'BRL',
            'PAYMENTREQUEST_0_ITEMAMT'       => $amount,
            'PAYMENTREQUEST_0_CUSTOM'        => $reference,

            'L_PAYMENTREQUEST_0_NAME0'    => $name,
            'L_PAYMENTREQUEST_0_DESC0'    => $description,
            'L_PAYMENTREQUEST_0_QTY0'     => $quantity,
            'L_PAYMENTREQUEST_0_AMT0'     => $amount,
            'L_PAYMENTREQUEST_0_ITEMAMT0' => $amount,

            'RETURNURL'    => $return['return'],
            'CANCELURL'    => $return['cancel']
        );

        $responseNvp = $this->sendNvpRequest($requestNvp, $this->sandbox);

        $this->setSession($requestNvp);

        if (isset($responseNvp['ACK']) && $responseNvp['ACK'] == 'Success') {
            $query = array(
                'cmd'    => '_express-checkout',
                'token'  => $responseNvp['TOKEN']
            );

            $subs = http_build_query($query);
            $url  = $this->getURL().'?'.$subs;
            $r = [
                'response' => 'ok',
                'url'  => $url
            ];
            echo json_encode($r);
            exit();
        } else {
            $r = [
                'response' => 'error',
                'message'  => 'Ocorreu um erro com o PayPal IPN'
            ];
            echo json_encode($r);
        }
    }

    public function AuthorizationCheckout($notifyURL, $token, $payerid) {
        $requestNvp1 = array(
            'USER'     	=> $this->ppEmail,
            'PWD'       => $this->ppPswd,
            'SIGNATURE' => $this->ppSignature,

            'VERSION' => '204.0',
            'METHOD'  => 'DoExpressCheckoutPayment',

            'TOKEN'   => $token,
            'PAYERID' => $payerid,

            'PAYMENTREQUEST_0_PAYMENTACTION' => 'Sale',
            'PAYMENTREQUEST_0_AMT'           => $this->getInfo('PAYMENTREQUEST_0_AMT'),
            'PAYMENTREQUEST_0_CURRENCYCODE'  => 'BRL',
            'PAYMENTREQUEST_0_ITEMAMT'       => $this->getInfo('PAYMENTREQUEST_0_AMT'),
            'PAYMENTREQUEST_0_CUSTOM'        => $this->getInfo('PAYMENTREQUEST_0_CUSTOM'),
            'PAYMENTREQUEST_0_NOTIFYURL'     => $notifyURL,

            'L_PAYMENTREQUEST_0_NAME0'    => $this->getInfo('L_PAYMENTREQUEST_0_NAME0'),
            'L_PAYMENTREQUEST_0_DESC0'    => $this->getInfo('L_PAYMENTREQUEST_0_DESC0'),
            'L_PAYMENTREQUEST_0_QTY0'     => $this->getInfo('L_PAYMENTREQUEST_0_QTY0'),
            'L_PAYMENTREQUEST_0_AMT0'     => $this->getInfo('L_PAYMENTREQUEST_0_AMT0'),
            'L_PAYMENTREQUEST_0_ITEMAMT0' => $this->getInfo('L_PAYMENTREQUEST_0_ITEMAMT0')
        );

        $responseNvp = $this->sendNvpRequest($requestNvp1);

        $transactionId = $responseNvp['PAYMENTINFO_0_TRANSACTIONID'];

        $requestNvp2 = array(
            'USER'     	=> $this->ppEmail,
            'PWD'       => $this->ppPswd,
            'SIGNATURE' => $this->ppSignature,

            'VERSION' => '204.0',
            'METHOD'=> 'DoAuthorization',

            'TRANSACTIONID' => $transactionId,
            'AMT' => $this->getInfo('L_PAYMENTREQUEST_0_QTY0'),
            'CURRENCYCODE' => 'BRL'
        );

        $this->sendNvpRequest($requestNvp2);
    }

    public function notify()
    {
        $req = 'cmd=_notify-validate';

        $url = (Config::SANDBOX) ? 'https://www.sandbox.paypal.com/cgi-bin/webscr' : 'https://www.paypal.com/cgi-bin/webscr';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($_POST));
        $result = curl_exec($ch);
        curl_close($ch);

        if(strcmp($result, "VERIFIED")) {
            $arry = [
                'id'        => $_POST['txn_id'],
                'status'    => $_POST['payment_status'],
                'reference' => $_POST['custom'],
                'amount'    => $_POST['mc_gross'] - $_POST['mc_fee'],
                'gross'     => $_POST['mc_gross'],
                'email'     => $_POST['payer_email'],
                'name'      => $_POST['first_name'] . " " . $_POST['last_name'],
                'paid'      => ($_POST['payment_status'] == 'Completed') ? 1 : 0
            ];
            $json = json_encode($arry);
            return json_decode($json);

        }elseif (strcmp ($result, "INVALID")) {
            printf("INVALID");
        }
    }

    private function sendNvpRequest(array $requestNvp) {

        $apiEndpoint  = 'https://api-3t.' . ($this->sandbox ? 'sandbox.': null);
        $apiEndpoint .= 'paypal.com/nvp';

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $apiEndpoint);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($requestNvp));

        $response = urldecode(curl_exec($curl));

        curl_close($curl);

        $responseNvp = array();

        if (preg_match_all('/(?<name>[^\=]+)\=(?<value>[^&]+)&?/', $response, $matches)) {
            foreach ($matches['name'] as $offset => $name) {
                $responseNvp[$name] = $matches['value'][$offset];
            }
        }

        if (isset($responseNvp['ACK']) && $responseNvp['ACK'] != 'Success') {
            for ($i = 0; isset($responseNvp['L_ERRORCODE' . $i]); ++$i) {
                $message = sprintf("PayPal NVP %s[%d]: %s\n",
                    $responseNvp['L_SEVERITYCODE' . $i],
                    $responseNvp['L_ERRORCODE' . $i],
                    $responseNvp['L_LONGMESSAGE' . $i]);

                error_log($message);
            }
        }

        return $responseNvp;
    }

    private function getURL() {
        if($this->sandbox) {
            return 'https://www.sandbox.paypal.com/cgi-bin/webscr';
        }else{
            return 'https://www.paypal.com/cgi-bin/webscr';
        }
    }

    private function setSession(array $informations) { $_SESSION['paypalCheckoutInformations'] = $informations; }

    private function getInfo($info) { $i = $_SESSION['paypalCheckoutInformations']; return $i[$info]; }
}