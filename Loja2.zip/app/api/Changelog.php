<?php

namespace app\api;

use app\lib\Json;
use app\lib\Model;
use app\lib\Security;

class Changelog
{

    private $model;

    public function __construct()
    {
        $this->model = new Model();
        $this->table();
    }

    public function add()
    {
        if (!Security::connection()) {
            return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']);
        }
        if (!isset($_POST)) {
            return Json::response(['response' => 'error', 'message' => 'No method submitted']);
        }
        if (empty($_POST['title']) || empty($_POST['topic'])) {
            return Json::response(['response' => 'error', 'message' => 'Insira todos os campos']);
        }

        $stmt = $this->model->getConnection()->prepare("INSERT INTO `website_changelogs`(`changelog_TITLE`, `changelog_TOPIC`, `changelog_DATE`) VALUES (?, ?, ?)");
        $stmt->execute([$_POST['title'], $_POST['topic'], date("Y-m-d H:i:s")]);
        return Json::response(['response' => 'ok']);
    }

    public function delete()
    {
        if (!Security::connection()) {
            return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']);
        }
        if (!isset($_POST)) {
            return Json::response(['response' => 'error', 'message' => 'No method submitted']);
        }

        $stmt = $this->model->getConnection()->prepare("DELETE FROM `website_changelogs` WHERE `changelog_ID` = ?");
        $stmt->execute([$_POST['id']]);

        return Json::response(['response' => 'ok']);
    }

    public function edit()
    {
        if (!Security::connection()) {
            return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']);
        }
        if (!isset($_POST)) {
            return Json::response(['response' => 'error', 'message' => 'No method submitted']);
        }

        $stmt = $this->model->getConnection()->prepare("UPDATE `website_changelogs` SET `changelog_TOPIC`=? WHERE `changelog_ID`=?");
        $stmt->execute([$_POST['topic'], $_POST['id']]);

        return Json::response(['response' => 'ok']);
    }

    public function count()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_changelogs`");
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function listall()
    {
        if ($this->count() == 0) {
            return "<h5 class='text-muted' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%)'>Não há atualizações</h5>";
        }

        $changelogs = "";
        $dates = $this->getDates();
        $i = 0;

        foreach ($dates as $rsd => $date) {
            $titles = $this->getTitles($date);
            $datef = date("d/m/Y", strtotime($date));
            $changelogers = "<ul class=\"changelog-list\">";
            foreach ($titles as $rst => $title) {
                $changelogers .= "<div class=\"title\">{$title->changelog_TITLE}</div>";
                $topics = $this->getTopics($title->changelog_TITLE, $date);
                foreach ($topics as $topic) {
                    $changelogers .= " <li class='input-box-{$topic['id']}'>
                                          <form method=\"post\" class=\"editChange\">
                                            <input name=\"id\" value=\"{$topic['id']}\" type=\"hidden\">
                                            <div class=\"input-box\">
                                              <input name=\"topic\" value=\"{$topic['topic']}\">
                                              <div class=\"button-box\">
                                                <button class=\"edit\"><i class=\"ion-edit\"></i></button>
                                                <button type=\"button\" class=\"delete del-change\" id='{$topic['id']}'><i class=\"ion-trash-b\"></i></button>
                                              </div>
                                            </div>
                                          </form>
                                        </li>";
                }
            }
            $changelogers .= "</ul>";
            $changelogs .= "<div class=\"cupom\">
                            <div class=\"row\">
                                <div class=\"col-md-8\">
                                    <div class=\"name mid\">
                                        {$datef}
                                    </div>
                                </div>
                                <div class=\"col-md-4\">
                                    <button data-toggle=\"modal\" data-target=\"#modal-{$i}\">detalhes</button>
                                </div>
                            </div>
                        </div>
                        <div class=\"modal fade\" id=\"modal-{$i}\" tabindex=\"-1\" role=\"dialog\">
                          <div class=\"modal-dialog\" role=\"document\">
                            <div class=\"modal-content\">
                              <div class=\"modal-header\">
                                <h5 class=\"modal-title\">Editar</h5>
                                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                                  <span aria-hidden=\"true\">&times;</span>
                                </button>
                              </div>
                              <div class=\"modal-body\">
                                {$changelogers}
                              </div>
                            </div>
                          </div>
                        </div>";
        }
        return $changelogs;
    }

    public function printall()
    {
        $datas  = $this->getDates();

        if(count($datas) == 0) { return "<h3 class='text-muted text-center'>Não há atualizações</h3>"; }

        $qnt    = 1;
        $atual  = (isset($_GET['p'])) ? intval($_GET['p']) : 1;
        rsort($datas);
        $pag    = array_chunk($datas, $qnt);
        $count  = count($pag);
        $result = $pag[$atual-1];

        $return = "<div class='row'>";
        foreach ($result as $data)
        {
            $date = date('d/m/Y', strtotime($data));

            if($date == date("d/m/Y")) { $date = "Hoje"; }

            $return .= "<div class='col-md-3'>
                            <h3 class='text-muted float-right'>{$date}</h3>
                        </div> 
                        <div class='col-md-9'>";
            $titles = $this->getTitles($data);
            foreach ($titles as $rst => $title)
            {
                $return .= "<ul><h5>{$title->changelog_TITLE}</h5><ul style=' margin: 0;'>";
                $topics = $this->getTopics($title->changelog_TITLE, $data);
                $topicos = "";
                foreach ($topics as $topic)
                {
                    $topicos .= "<li>{$topic['topic']}</li>";
                }
                $return .= "{$topicos}</ul></ul>";
            }
            $return .= "</div>";
        }

        $pags = "";
        for($i = 1; $i <= $count; $i++)
        {
            if($i == $atual) {
                $pags .= "<li class=\"page-item active\">
                              <a class=\"page-link\" href=\"/atualizacoes?p={$i}\">{$i} <span class=\"sr-only\">(current)</span></a>
                          </li>";
            }else{
                $pags .= "<li class=\"page-item\">
                              <a class=\"page-link\" href=\"/atualizacoes?p={$i}\">{$i}</a>
                            </li>";
            }
        }
        $pagination = "<br><br>
                        <nav>
                          <ul class=\"pagination\">
                            <li class=\"page-item\"><a class=\"page-link\" href=\"/atualizacoes?p=1\">Primeira</a></li>
                            {$pags}
                            <li class=\"page-item\"><a class=\"page-link\" href=\"/atualizacoes?p={$count}\">Última</a></li>
                          </ul>
                        </nav>";
        return $return."</div>".$pagination;
    }

    private function getDates()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT `changelog_DATE` FROM `website_changelogs` ORDER BY `changelog_ID` DESC");
        $stmt->execute();
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $array = [];
        foreach ($fetch as $rs)
        {
            $date = explode(' ', $rs->changelog_DATE);
            $array[] = $date[0];

        }
        return array_unique($array);
    }

    private function getTitles($date)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT DISTINCT `changelog_TITLE` FROM `website_changelogs` WHERE `changelog_DATE` LIKE '%{$date}%'");
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_OBJ);
    }

    private function getTopics($title, $date)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT `changelog_TOPIC`, `changelog_ID` FROM `website_changelogs` WHERE `changelog_DATE` LIKE '%$date%' AND `changelog_TITLE` LIKE '%$title%'");
        $stmt->execute();
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $topics = [];
        foreach ($fetch as $rs)
        {
            array_push($topics,
                [
                    'id'    => $rs->changelog_ID,
                    'topic' => $rs->changelog_TOPIC
                ]
            );
        }
        return $topics;
    }

    private function table()
    {
        $create = $this->model->getConnection()->prepare("CREATE TABLE IF NOT EXISTS `website_changelogs` (
                                                                      `changelog_ID` int(16) NOT NULL PRIMARY KEY AUTO_INCREMENT,
                                                                      `changelog_TITLE` varchar(255) NOT NULL,
                                                                      `changelog_TOPIC` varchar(255) NOT NULL,
                                                                      `changelog_DATE` datetime NOT NULL
                                                                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        $create->execute();
    }
}