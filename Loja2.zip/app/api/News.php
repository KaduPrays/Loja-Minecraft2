<?php

namespace app\api;

use app\lib\Json;
use app\lib\Model;
use app\lib\Security;
use PDO;

class News
{

    private $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    public function add()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        if(empty($_POST['name']) || empty($_POST['author']) || empty($_POST['header']) || empty($_POST['resume'])) { return Json::response(['response' => 'error', 'message' => 'Preencha todos os dados']); }
        $stmt = $this->model->getConnection()->prepare("INSERT INTO `website_news`(`news_TITLE`, `news_AUTHOR`, `news_LINK`, `news_HEADER`, `news_RESUME`, `news_COMPLETE`, `news_DATE`) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$_POST['name'], $_POST['author'], $_POST['link'], $_POST['header'], $_POST['resume'], $_POST['complete'], date("Y-m-d H:i:s")]);

        $id = $this->model->getConnection()->lastInsertId();
        $link = $_POST['link'];
        if(empty($link)) {
            $links = str_replace(" ", "-", strtolower($_POST['name']));
            $link = APP_ROOT."home/noticia/{$id}-{$links}";
        }

        Notifications::add("Nova notícia publicada", '*', $link);

        return Json::response(['response' => 'ok', 'message' => 'Notícia publicada com sucesso']);
    }

    public function count()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_news`");
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function delete()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        $stmt = $this->model->getConnection()->prepare("DELETE FROM `website_news` WHERE `news_ID`=?");
        $stmt->execute([$_POST['id']]);
    }

    public function listAll()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_news` ORDER BY `news_ID` DESC");
        $stmt->execute();
        if($stmt->rowCount() == 0) { return "<h5 class='text-muted' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%)'>Não há pacotes</h5>"; }
        $fetch = $stmt->fetchAll(PDO::FETCH_OBJ);
        $news = "";
        foreach ($fetch as $rs) {
            $date = date("d/m/Y", strtotime($rs->news_DATE));

            $link = $rs->news_LINK;

            if(empty($rs->news_LINK)) {
                $links = str_replace(" ", "-", strtolower($rs->news_TITLE));
                $link = APP_ROOT."home/noticia/{$rs->news_ID}-{$links}";
            }

            $news .= "<div class=\"feed feed-{$rs->news_ID}\">
                            <div class=\"row\">
                                <div class=\"col-md-8\">
                                    <div class=\"name mid\">
                                        {$rs->news_TITLE}
                                    </div>
                                </div>
                                <div class=\"col-md-4\">
                                    <button class=\"tr-modal-open\" id=\"{$rs->news_ID}\">detalhes</button>
                                </div>
                            </div>
                        </div>
                        <div class=\"tr-modal tr-open-{$rs->news_ID}\">
                            <div class=\"tr-title\">
                                Informações da notícia
                            </div>
                            <button class=\"tr-close\">
                                <i class=\"ion-ios-close-empty\"></i>
                            </button>
                            <br>
                            <div class=\"tr-body\">
                                <p>
                                    Título:
                                    <span class=\"float-right\">{$rs->news_TITLE}</span>
                                </p>
                                <p>
                                    Postado em:
                                    <span class=\"float-right\">{$date}</span>
                                </p>
                                <p>
                                    Autor:
                                    <span class=\"float-right\">{$rs->news_AUTHOR}</span>
                                </p>
                                <p>
                                    Link:
                                    <span class=\"float-right\">
                                        <a href='{$link}' target='_blank'>Abrir no navegador</a>
                                    </span>
                                </p>
                                <br>
                                <p>
                                    Deletar?
                                    <a href=\"javascript:void(0)\" class=\"float-right del-news\" style=\"color: red\" id=\"{$rs->news_ID}\">
                                        Sim
                                    </a>
                                </p>
                            </div>
                        </div>";
        }
        return $news;
    }

    public function printall()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }

        $init = $_POST['init'];
        $max  = $_POST['max'];

        $result = [
            'totalResults' => 0,
            'dados' => null
        ];

        $stmtTotal = $this->model->getConnection()->prepare("SELECT * FROM `website_news`");
        $stmtTotal->execute();
        $result['totalResults'] = $stmtTotal->rowCount();

        $stmtDados = $this->model->getConnection()->prepare("SELECT * FROM `website_news` ORDER BY `news_ID` DESC LIMIT $init, $max");
        $stmtDados->execute();
        if($result['totalResults'] > 0) {
            while ($r = $stmtDados->fetch(PDO::FETCH_OBJ)) {

                $link = $r->news_LINK;

                if(empty($link)) {
                    $links = str_replace(" ", "-", strtolower($r->news_TITLE));
                    $link = APP_ROOT."home/noticia/{$r->news_ID}-{$links}";
                }

                $arry[] = [
                    'id' => $r->news_ID,
                    'titulo' => $r->news_TITLE,
                    'autor' => $r->news_AUTHOR,
                    'imagem' => $r->news_HEADER,
                    'data' => $this->stringDate($r->news_DATE),
                    'hora' => $this->stringHour($r->news_DATE),
                    'resumo' => $r->news_RESUME,
                    'noticia' => $link
                ];
            }
            $result['dados'] = $arry;
        }

        header('Content-type: application/json');
        echo json_encode($result, JSON_PRETTY_PRINT);
    }

    public function single($params)
    {
        $id = explode("-", $params);
        $id = $id[0];

        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_news` WHERE `news_ID`=?");
        $stmt->execute([$id]);

        if($stmt->rowCount() == 0) { return "<h3 class='text-center text-muted' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);'>Notícia inválida</h3>"; }

        $rs = $stmt->fetchObject();

        $return = "<div style=\"margin-top: -170px;\">
                    <div class=\"mb-3\"> 
                        <div class=\"col-md-6 mx-auto\">
                            <div class=\"h1 text-center text-white\">{$rs->news_TITLE}</div>
                            <div class=\"h4 text-center text-white\">Por {$rs->news_AUTHOR}</div>
                        </div>
                     </div>
                    </div>
                    <div class=\"content card cardshadow\">
                        <img src='{$rs->news_HEADER}' class='img-fluid' style='width: 100%;'>
                        <br><br>
                        {$rs->news_COMPLETE}
                    </div>";

        return $return;
    }

    private function stringDate($date)
    {
        $array = [ '01' => 'JAN', '02' => 'FEV', '03' => 'MAR', '04' => 'ABR', '05' => 'MAI', '06' => 'JUN',
                   '07' => 'JUL', '08' => 'AGO', '09' => 'SET', '10' => 'OUT', '11' => 'NOV', '12' => 'DEZ' ];

        $date  = explode("/", date("d/m", strtotime($date)));

        return "<div class=\"day\">{$date[0]}</div><div class=\"month\">{$array[$date[1]]}</div>";
    }

    private function stringHour($date)
    {
        return date('h:i A', strtotime($date));
    }

}