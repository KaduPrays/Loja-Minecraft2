<?php

namespace app\api;


use app\lib\Config;

class BCash
{

    private $email;

    public function __construct()
    {
        $this->email = Config::BCASH_EMAIL;
    }

    public function checkout($arry)
    {
        return $this->post([
            'email_loja'          => $this->email,
            'produto_codigo_1'    => $arry['reference'],
            'produto_descricao_1' => $arry['description'],
            'produto_qtde_1'      => $arry['quantity'],
            'produto_valor_1'     => $arry['amount'],
            'url_retorno'         => $arry['return'],
            'url_aviso'           => $arry['notification'],
            'redirect'            => true,
            'redirect_time'       => 5,
            'free'                => $arry['custom']
        ], "https://www.bcash.com.br/pay/");
    }

    public function notify()
    {

    }

    private function post($arry, $url)
    {
        $cURL = curl_init();
        curl_setopt($cURL, CURLOPT_URL, $url);
        curl_setopt($cURL, CURLOPT_AUTOREFERER, true);
        curl_setopt($cURL, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($cURL, CURLOPT_POST, true);
        curl_setopt($cURL, CURLOPT_TIMEOUT, 20);
        curl_setopt($cURL, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($cURL, CURLOPT_HEADER, false);
        curl_setopt($cURL, CURLOPT_POSTFIELDS, $arry);
        $response = curl_exec($cURL);
        curl_close($cURL);
        return $response;
    }

}