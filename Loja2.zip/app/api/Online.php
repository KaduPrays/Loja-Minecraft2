<?php

namespace app\api;

use app\lib\Model;
use PDO;

class Online
{

    public $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    public function run()
    {
        if((isset($_SESSION['WebVisits']) AND (!empty($_SESSION['WebVisits'])))) {
            $this->reload($_SESSION['WebVisits']);
        }else{
            $_SESSION['WebVisits'] = $this->add();
        }
    }

    public function row()
    {
        $now = date('Y-m-d H:i:s');
        $end = date('Y-m-d H:i:s', strtotime($now."-20 seconds"));
        $stmt = $this->model->getConnection()->prepare("SELECT COUNT(`online_ID`) as online FROM `website_online` WHERE `online_END` >= ?");
        $stmt->execute([$end]);
        return $stmt->fetchObject()->online;
    }

    private function add()
    {
        $now = date('Y-m-d H:i:s');
        $end = date('Y-m-d H:i:s', strtotime($now."-20 seconds"));
        $stmt = $this->model->getConnection()->prepare("INSERT INTO `website_online`(`online_START`, `online_END`) VALUES (?, ?)");
        $stmt->execute([$now, $end]);
        return $this->model->getConnection()->lastInsertId();
    }

    private function reload($id)
    {
        $now = date('Y-m-d H:i:s');
        $end = date('Y-m-d H:i:s', strtotime($now."-20 seconds"));
        $stmt = $this->model->getConnection()->prepare("UPDATE `website_online` SET `online_START`=?, `online_END`=? WHERE `online_ID`=?");
        $stmt->execute([$now, $end, $id]);
    }

}