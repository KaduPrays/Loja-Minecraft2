<?php

namespace app\api;

use app\lib\Json;
use app\lib\Model;
use app\lib\Security;

class Profile
{

    private $model;

    public function  __construct()
    {
        $this->model = new Model();
    }

    public function login()
    {
        if(!Security::connection()) { return Json::response([ 'response' => 'error', 'message' => 'You\'re blocked by security system!' ]); }
        if(!isset($_POST)) { return Json::response([ 'response' => 'error', 'message' => 'Method not sent' ]); }
        if(empty($_POST['username'])) { return Json::response([ 'response' => 'error', 'message' => 'Informe seu nick in-game.' ]); }

        $_SESSION['WebUser'] = $_POST['username'];

        return Json::response(['response' => 'ok', 'message' => 'Redirecionando...']);
    }

    public function isLogged()
    {
        return isset($_SESSION['WebUser']);
    }

    public function logout()
    {
        unset($_SESSION['WebUser']);
        return;
    }

    public function purchases()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM website_transactions WHERE transaction_USERNAME = ?");
        $stmt->execute([$_SESSION['WebUser']]);
        if($stmt->rowCount() == 0) { return ""; }
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $table = "";
        foreach ($fetch as $rs) {
            $amount = 'R$'.number_format($rs->transaction_GROSS, 2, ',', '.');
            $table .= "<tr>
                        <th scope=\"row\">{$rs->transaction_CODE}</th>
                        <td>{$amount}</td>
                        <td><button class=\"btn btn-warning btn-sm\" data-toggle=\"modal\" data-target=\"#md-{$rs->transaction_REFERENCE}\">ver carrinho</button></td>
                        <td>{$this->status($rs->transaction_STATUS)}</td>
                        <div class=\"modal fade\" id=\"md-{$rs->transaction_REFERENCE}\" tabindex=\"-1\" role=\"dialog\">
                            <div class=\"modal-dialog\" role=\"document\">
                                <div class=\"modal-content\">
                                    <div class=\"modal-header\">
                                        <h5 class=\"modal-title\" id=\"exampleModalLabel\">Itens do carrinho</h5>
                                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                                            <span aria-hidden=\"true\">&times;</span>
                                        </button>
                                    </div>
                                    <div class=\"modal-body\">
                                        <ul class=\"cart-itens\">
                                            {$this->productsli($rs->transaction_REFERENCE)}
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </tr>";
        }
        return $table;
    }

    private function productsli($reference)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM website_references WHERE reference_ID=?");
        $stmt->execute([$reference]);
        $reference = $stmt->fetchObject()->reference_PACKAGES;
        $reference = explode(";", $reference);
        $li = "";
        foreach ($reference as $rs)
        {
            $info = explode(":", $rs);
            if($info[0] == 'unban')
            {
                $li .= "<li>Unban <span>Global</span></li>";
            }else{
                $info = $this->getInfo($info[0]);
                $li .= "<li>{$info['name']} <span>{$info['server']}</span></li>";
            }
        }
        return $li;
    }

    private function getInfo($package)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM website_packages WHERE package_ID=?");
        $stmt->execute([$package]);
        $fetch = $stmt->fetchObject();

        $name   = $fetch->package_NAME;
        $server = $fetch->package_SERVER;

        $stmt = $this->model->getConnection()->prepare("SELECT * FROM website_servers WHERE server_ID = ?");
        $stmt->execute([$server]);
        $server = $stmt->fetchObject()->server_NAME;

        return [
            'name'   => $name,
            'server' => $server
        ];
    }


    private function status($str)
    {
        $status = [
            'pending'      => "Pendente",
            'approved'     => "Pago",
            'in_process'   => "Em análise",
            'in_mediation' => "Em disputa",
            'rejected'     => "Recusado",
            'cancelled'    => "Cancelado",
            'charged_back' => 'Devolvido',
            'refunded'     => 'Devolvido',
            'Canceled_Reversal' => 'Pago',
            'Completed'         => 'Pago',
            'Created'           => 'Aguardando pagamento',
            'Denied'            => 'Recusado',
            'Expired'           => 'Expirado',
            'Failed'            => 'Falha',
            'Pending'           => 'Aguardando pagamento',
            'Refunded'          => 'Devolvido',
            'Reversed'          => 'Em disputa',
            'Voided'            => 'Em análise',
            'Processed'         => 'Aguardando pagamento'
        ];
        return $status[$str];
    }

}