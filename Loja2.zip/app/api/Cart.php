<?php

namespace app\api;

use app\lib\Config;
use app\lib\Json;
use app\lib\Model;
use PDO;
use app\lib\Security;

class Cart extends Model
{

    private $pdo;

    public function __construct()
    {
        $model = new Model;
        $this->pdo = $model->getConnection();
        if (!isset($_SESSION['WebCart'])) {
            $_SESSION['WebCart'] = array();
        }
    }

    public function add()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'What method?']); }
        if(empty($_POST['id'])) { return Json::response(['response' => 'error', 'message' => 'Empty params']); }

        $i = explode("-", $_POST['id']);

        if (is_null($i[1])) {
            $indice = sprintf("%s:%s", $i[0], '0');
        } else {
            $indice = sprintf("%s:%s", (int)$i[0], (int)$i[1]);
        }
        if (!isset($_SESSION['WebCart'][$indice])) {
            $_SESSION['WebCart'][$indice] = 1;
        }
        return Json::response(['response' => 'ok']);
    }

    public function remove()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'What method?']); }
        if(empty($_POST['id'])) { return Json::response(['response' => 'error', 'message' => 'Empty params']); }
        unset($_SESSION['WebCart'][$_POST['id']]);
    }

    public function listPackages()
    {
        $return = array();
        foreach ($_SESSION['WebCart'] as $indice => $qnt) {
            list($package, $server) = explode(":", $indice);

            if($package == "unban")
            {
                $return[$indice]['id'] = "unban";
                $return[$indice]['title'] = "Unban";
                $return[$indice]['price'] = Config::UNBAN_AMOUNT;
                $return[$indice]['server'] = 0;
            }else
            {
                $stmt = $this->pdo->prepare("SELECT * FROM `website_packages` WHERE `package_ID`=?");
                $stmt->execute([$package]);

                $result = $stmt->fetchObject();

                $return[$indice]['id'] = $result->package_ID;
                $return[$indice]['title'] = $result->package_NAME;
                $return[$indice]['price'] = $result->package_AMOUNT;
                $return[$indice]['server'] = $server;
            }
        }
        return $return;
    }

    public function totalAmount()
    {
        $packages = $this->listPackages();
        $total = 0;
        foreach ($packages as $indice => $linha) {
            $total += $linha['price'];
        }
        return $total;
    }

    public function getServername($server)
    {
        if($server == 0) {
            return "GLOBAL";
        }
        $stmt = $this->pdo->prepare("SELECT * FROM `website_servers` WHERE `server_ID` = ?");
        $stmt->execute([$server]);

        return strtoupper($stmt->fetchObject()->server_NAME);
    }

    public function transactions()
    {
        $stmt = $this->pdo->prepare("SELECT * FROM `website_transactions` WHERE `transaction_USERNAME`=?");
        $stmt->execute([$_SESSION['WebUser']]);
        if($stmt->rowCount() == 0) { return "<tr><td colspan=\"4\" align=\"center\">Você ainda não comprou nada</td></tr>"; }
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $transactions = "";
        foreach ($fetch as $rs) {
            $transactions .= "<tr>
                                <th>{$rs->transaction_CODE}</th>
                                <td>{$rs->transaction_GATEWAY}</td>
                                <td><button class=\"btn btn-sm btn-primary\" data-toggle=\"modal\" data-target=\"#compra-{$rs->transaction_REFERENCE}\">Ver pacotes</button></td>
                                <td align=\"center\">{$this->status($rs->transaction_STATUS)}</td>
                            </tr>
                            <div class=\"modal fade\" id=\"compra-{$rs->transaction_REFERENCE}\" tabindex=\"-1\" role=\"dialog\">
                                <div class=\"modal-dialog\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <div class=\"modal-header\">
                                            <h5 class=\"modal-title\">Pacotes comprados</h5>
                                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                                                <span>&times;</span>
                                            </button>
                                        </div>
                                        <div class=\"modal-body\">
                                            <p style=\"text-align: justify;\">
                                                <h5>Agradecemos pela compra!</h5>
                                                <p>Abaixo estão listados os pacotes que você comprou</p>
                                            </p>
                                            <br>
                                            <div class='row'>
                                                <div class='col-md-4'>
                                                    <p class='text-center text-muted'>Produto</p>
                                                </div>
                                                <div class='col-md-4'>
                                                    <p class='text-center text-muted'>Servidor</p>
                                                </div>       
                                                <div class='col-md-4'>
                                                    <p class='text-center text-muted'>Preço</p>
                                                </div>                          
                                            </div>
                                            {$this->getPackages($rs->transaction_REFERENCE)}
                                        </div>
                                    </div>
                                </div>
                            </div>";
        }
        return $transactions;
    }

    public function getPackages($reference)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM `website_references` WHERE `reference_ID`=?");
        $stmt->execute([$reference]);
        $packages = explode(";", $stmt->fetchObject()->reference_PACKAGES);
        $return = "";
        foreach ($packages as $item)
        {
            $item = explode(":", $item);
            $info = $this->getPackageInfo($item[0]);

            $server =  $item[1];

            $return .= "<div class='row'>
                            <div class='col-md-4'>
                                <p class='text-center'>{$info['name']}</p>
                            </div>
                            <div class='col-md-4'>
                                <p class='text-center'>{$server}</p>
                            </div>       
                            <div class='col-md-4'>
                                <p class='text-center'>{$info['amt']}</p>
                            </div>                          
                        </div>";
        }
        return $return;
    }

    public function hot()
    {
        $stmt = $this->pdo->prepare("SELECT * FROM `website_hot` WHERE `hot_MONTH`=? AND `hot_PACKAGE`!=0 ORDER BY `hot_SALES` DESC LIMIT 1");
        $stmt->execute([date("m/Y")]);
        if ($stmt->rowCount() > 0) {
            $id = $stmt->fetchObject()->hot_PACKAGE;
            $get = $this->pdo->prepare("SELECT * FROM `website_packages` WHERE `package_ID`=?");
            $get->execute([$id]);
            $fetch = $get->fetchObject();
            $image = $fetch->package_IMAGE;
            $name = $fetch->package_NAME;
            $price = "R$" . number_format($fetch->package_AMOUNT, 2, ",", ".");
            $server = $fetch->package_SERVER;

            return "<div class=\"card\">
                <div class=\"card-header\">
                    <i class=\"ion-fireball\"></i>
                    Produto mais vendido
                </div>
                <div class=\"card-body\">
                    <div class=\"hot-package\">
                        <img src=\"{$image}\" class=\"img-fluid\" ult=\"Rede Waze - Destaque do mês\">
                        <div class=\"title\">{$name}</div>
                        <div class=\"price\">{$price}</div>
                        <button class=\"btn btn-info add-to-cart\" id='{$id}-{$server}' style='width: 100%'>ver detalhes</button>
                    </div>
                </div>
            </div>";
        }
    }

    private function status($str)
    {
        $status = [
            //PagSeguro
            1 => "Pendente",
            2 => "Em análise",
            3 => "Pago",
            4 => "Pago",
            5 => "Em disputa",
            6 => "Devolvido",
            7 => "Cancelado",
            8 => 'Devolvido',
            9 => "Retido",
            //MercadoPago
            'pending'      => "Pendente",
            'approved'     => "Pago",
            'in_process'   => "Em análise",
            'in_mediation' => "Em disputa",
            'rejected'     => "Recusado",
            'cancelled'    => "Cancelado",
            'charged_back' => 'Devolvido',
            //PayPal
            'Canceled_Reversal' => 'Pago',
            'Completed'         => 'Pago',
            'Created'           => 'Pendente',
            'Denied'            => 'Recusado',
            'Expired'           => 'Expirado',
            'Failed'            => 'Falha',
            'Pending'           => 'Pendente',
            'Refunded'          => 'Devolvido',
            'Reversed'          => 'Em disputa',
            'Voided'            => 'Em análise',
            'Processed'         => 'Pendente'
        ];
        return $status[$str];
    }

    private function getPackageInfo($id)
    {
        if($id == 'unban')
        {
            return [
                'name' => 'Unban',
                'amt'  => 'R$'.number_format(Config::UNBAN_AMOUNT, 2, ',', '.')
            ];
        }
        $stmt = $this->pdo->prepare("SELECT * FROM `website_packages` WHERE `package_ID`=?");
        $stmt->execute([$id]);
        $fetch = $stmt->fetch(\PDO::FETCH_OBJ);

        return [
            'name' => $fetch->package_NAME,
            'amt'  => 'R$'.number_format($fetch->package_AMOUNT, 2, ',', '.')
        ];
    }

    public function printMeta()
    {
        $stmt = $this->pdo->prepare("SELECT SUM(transaction_AMOUNT) as soma FROM `website_transactions` WHERE `transaction_MONTH`=? AND `transaction_PAID`=?;");
        $stmt->execute([date("m/Y"), 1]);
        $total = "";
        while($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $total = $data['soma'];
        }
        $p = round((($total * 100) / Config::META));

        if($p > 100) {
            $p = 100;
        }

        $html = "<div class=\"progress\"> \n
                    <div class=\"progress-bar progress-bar-striped progress-bar-animated\" role=\"progressbar\" style=\"width: {$p}%\" aria-valuenow=\"100\" aria-valuemin=\"0\" aria-valuemax=\"100\">{$p}%</div> \n
                 </div> \n";

        if($p >= 100) {
            $html = "<div class=\"progress\"> \n
                        <div class=\"progress-bar progress-bar-striped progress-bar-animated\" role=\"progressbar\" style=\"width: {$p}%\" aria-valuenow=\"100\" aria-valuemin=\"0\" aria-valuemax=\"100\">{$p}%</div> \n
                    </div> \n 
                    <h6 class='text-center text-muted' style='margin-top: 6px; font-size: 12px'>Agradecemos a todos que ajudaram!</h6> \n";
        }

        return "<div class=\"card\">
                <div class=\"card-header\">META MENSAL </div>
                <div class=\"card-body\">
                    {$html}
                </div>
            </div>";
    }
}