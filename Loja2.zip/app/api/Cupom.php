<?php

namespace app\api;

use app\lib\Json;
use app\lib\Model;
use app\lib\Security;
use PDO;

class Cupom
{

    private $model, $cart;

    public function __construct()
    {
        $this->cart  = new Cart();
        $this->model = new Model();
    }

    public function run($hash) {
        if(!isset($_POST)) {  return Json::response(['response' => 'error', 'message' => 'Nada enviado.']); }
        if(!$this->verify($hash)) { return Json::response(['response' => 'error', 'message' => 'Cupom não existe']); }
        if(!$this->isValid($hash)) { return Json::response(['response' => 'error']); }
        $total = $this->cart->totalAmount();
        $packages = $this->cart->listPackages();
        $valor    = 0;
        foreach ($packages as $indice => $package) {
            $valor += $package['price'];
        }
        $discount = $this->discount($valor, $this->getPercent($hash));
        $_SESSION['WebStoreDiscount'] = $discount;
        $_SESSION['WebCupom']         = $hash;

        return Json::response(
            [
                'response' => 'ok',
                'total' => 'R$'.number_format($total - $discount, 2, ',', '.'),
                'discount' => 'R$'.number_format(doubleval($discount), 2, ',', '.')
            ]
        );
    }

    public function apply($hash, $amount)
    {
        if(!$this->verify($hash)) { return $amount; }
        if(!$this->isValid($hash)) { return $amount; }
        $percent = $this->getPercent($hash);
        return $amount - $this->discount($amount, $percent);
    }

    public function add()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        if(empty($_POST['hash']) || empty($_POST['percent']) || empty($_POST['expire'])) { return Json::response(['response' => 'error', 'message' => 'Insira todos os dados do cupom']); }
        if($this->verify($_POST['hash'])) { return Json::response(['response' => 'error', 'message' => 'Já existe um cupom com esta hash']); }
        $stmt = $this->model->getConnection()->prepare("INSERT INTO `website_cupons`(`cupom_HASH`, `cupom_PERCENT`, `cupom_EXPIRE`) VALUES (?,?,?)");
        $stmt->execute([$_POST['hash'], $_POST['percent'], $_POST['expire']]);

        Notifications::add("Cupom {$_POST['hash']} adicionado!");

        return Json::response(['response' => 'ok', 'message' => 'Cupom registrado com sucesso']);
    }

    public function listall()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_cupons` ORDER BY `cupom_ID` DESC");
        $stmt->execute();
        if($stmt->rowCount() == 0) { return "<h5 class='text-muted' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%)'>Não há cupons</h5>"; }
        $fetch = $stmt->fetchAll(PDO::FETCH_OBJ);
        $cupons = "";
        foreach ($fetch as $rs) {

            $validate = date("d/m/Y", strtotime($rs->cupom_EXPIRE));

            if(strtotime(date("Y-m-d")) > strtotime($rs->cupom_EXPIRE)) { $validate = "EXPIRADO!"; }

            $cupons.="<div class=\"cupom cupom-{$rs->cupom_ID}\">
                            <div class=\"row\">
                                <div class=\"col-md-3\">
                                    <div class=\"hash\">
                                        {$rs->cupom_HASH}
                                    </div>
                                </div>
                                <div class=\"col-md-5\">
                                    <div class=\"expire\">
                                        {$validate}
                                    </div>
                                </div>
                                <div class=\"col-md-4\">
                                    <button class=\"tr-modal-open\" id=\"{$rs->cupom_ID}\">detalhes</button>
                                </div>
                            </div>
                        </div>
                        <div class=\"tr-modal tr-open-{$rs->cupom_ID}\">
                            <div class=\"tr-title\">
                                Dados do pacote
                            </div>
                            <button class=\"tr-close\">
                                <i class=\"ion-ios-close-empty\"></i>
                            </button>
                            <br>
                            <div class=\"tr-body\">
                                <p>
                                    Código:
                                    <span class=\"float-right\">{$rs->cupom_HASH}</span>
                                </p>
                                <p>
                                    Desconto:
                                    <span class=\"float-right\">{$rs->cupom_PERCENT}%</span>
                                </p>
                                <p>
                                    Válido até:
                                    <span class=\"float-right\">{$validate}</span>
                                </p>
                                <p>
                                    Deletar?
                                    <a href=\"javascript:void(0)\" class=\"float-right del-cupom\" style=\"color: red\" id=\"{$rs->cupom_ID}\">
                                        Sim
                                    </a>
                                </p>
                            </div>
                        </div>";
        }
        return $cupons;
    }

    public function delete()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        $stmt = $this->model->getConnection()->prepare("DELETE FROM `website_cupons` WHERE `cupom_ID`=?");
        $stmt->execute([$_POST['id']]);
        return Json::response(['response' => 'ok']);
    }

    public function count()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_cupons`");
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function addToAffiliate($hash, $discount)
    {
        $stmt = $this->model->getConnection()->prepare("INSERT INTO `website_cupons`(`cupom_HASH`, `cupom_PERCENT`, `cupom_EXPIRE`) VALUES (?, ?, ?)");
        $stmt->execute([$hash, $discount, "3000/12/25"]);
    }

    public function removeToAffiliate($hash)
    {
        $stmt = $this->model->getConnection()->prepare("DELETE FROM `website_cupons` WHERE `cupom_HASH`=?");
        $stmt->execute([$hash]);
    }

    private function verify($hash)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT `cupom_HASH` FROM `website_cupons` WHERE `cupom_HASH`=?");
        $stmt->execute([$hash]);
        return $stmt->rowCount() > 0;
    }

    private function isValid($hash)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT `cupom_EXPIRE` FROM `website_cupons` WHERE `cupom_HASH`=?");
        $stmt->execute([$hash]);
        $now = date("Y-m-d");
        $end = $stmt->fetchObject()->cupom_EXPIRE;
        return (strtotime($end) >= strtotime($now));
    }

    private function getPercent($hash)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT `cupom_PERCENT` FROM `website_cupons` WHERE `cupom_HASH`=?");
        $stmt->execute([$hash]);
        return $stmt->fetchObject()->cupom_PERCENT;
    }

    private function discount($amount, $percent)
    {
        return $amount * $percent / 100;
    }
}