<?php

namespace app\api;

use app\lib\Json;
use app\lib\Model;
use app\lib\Security;
use PDO;

class Packages
{

    public $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    public function add()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        $category = (empty($_POST['category'])) ? 0 : $_POST['category'];
        if(empty($_POST['name']) || empty($_POST['amount']) || empty($_POST['description']) || empty($_POST['commands']) || empty($_POST['image'])) { return Json::response(['response' => 'error', 'message' => 'Informe todos os dados do pacote']); }
        $commands = "";
        foreach ($_POST['commands'] as $rs) {
            $commands .= "{$rs};";
        }
        $commands = substr($commands, 0, -1);
        $stmt = $this->model->getConnection()->prepare("INSERT INTO `website_packages`(`package_NAME`, `package_AMOUNT`, `package_SERVER`, `package_IMAGE`, `package_DESCRIPTION`, `package_COMMANDS`) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$_POST['name'], $_POST['amount'], $category, $_POST['image'], $_POST['description'], $commands]);

        return Json::response(['response' => 'ok', 'message' => 'Pacote salvo com sucesso!']);
    }

    public function delete()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        $stmt = $this->model->getConnection()->prepare("DELETE FROM `website_packages` WHERE `package_ID`=?");
        $stmt->execute([$_POST['id']]);
    }

    public function listAll()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_packages` ORDER BY `package_ID` DESC");
        $stmt->execute();
        if($stmt->rowCount() == 0) { return "<h5 class='text-muted' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%)'>Não há pacotes</h5>"; }
        $fetch = $stmt->fetchAll(PDO::FETCH_OBJ);
        $packages = "";
        foreach ($fetch as $rs) {

            $amount   = "R$".number_format($rs->package_AMOUNT, 2, ',', '.');
            $commands = explode(";", $rs->package_COMMANDS);
            $command  = "";
            foreach ($commands as $r) {
                $command.="$r <br>";
            }
            $packages .= "<div class=\"package package-{$rs->package_ID}\">
                            <div class=\"row\">
                                <div class=\"col-md-3\">
                                    <div class=\"name\">
                                        {$rs->package_NAME}
                                    </div>
                                </div>
                                <div class=\"col-md-5\">
                                    <div class=\"server\">
                                        {$rs->package_SERVER}
                                    </div>
                                </div>
                                <div class=\"col-md-4\">
                                    <button class=\"tr-modal-open\" id=\"{$rs->package_ID}\">detalhes</button>
                                </div>
                            </div>
                        </div>
                        <div class=\"tr-modal tr-open-{$rs->package_ID}\">
                            <div class=\"tr-title\">
                                Dados do pacote
                            </div>
                            <button class=\"tr-close\">
                                <i class=\"ion-ios-close-empty\"></i>
                            </button>
                            <br>
                            <div class=\"tr-body\">
                                <p>
                                    Nome:
                                    <span class=\"float-right\">{$rs->package_NAME}</span>
                                </p>
                                <p>
                                    Servidor:
                                    <span class=\"float-right\">{$rs->package_SERVER}</span>
                                </p>
                                <p>
                                    Valor:
                                    <span class=\"float-right\">{$amount}</span>
                                </p>
                                <p>
                                    Comando:
                                    <small class=\"float-right\">
                                        {$command}
                                    </small>
                                </p>
                                <br>
                                <p>
                                    Deletar?
                                    <a href=\"javascript:void(0)\" class=\"float-right del-package\" style=\"color: red\" id=\"{$rs->package_ID}\">
                                        Sim
                                    </a>
                                </p>
                            </div>
                        </div>";
        }
        return $packages;
    }

    public function count()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_packages`");
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function printCategory($category)
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_packages` WHERE `package_SERVER`=? ORDER BY `package_ID` DESC ");
        $stmt->execute([$category]);
        if($stmt->rowCount() == 0) { return "<h5 class='text-center text-muted'>Ops.. parece que estamos sem pacotes para vender. <br> Volte mais tarde</h5>"; }
        $packages = "<div class=\"row\">";
        $fetch    = $stmt->fetchAll(PDO::FETCH_OBJ);
        foreach ($fetch as $rs)
        {
            $price     = "R$".number_format($rs->package_AMOUNT, 2, ',', '.');
            $name      = str_replace('+', 'plus', $rs->package_NAME);
            $name      = strtolower(str_replace(' ', '-', $name));
            $link      = "{$rs->package_ID}-$name";
            $server    = $rs->package_SERVER;

            $details = "";
            if($server != 0) { $details = "<button class=\"btn btn-danger\" onclick=\"goTo('/loja/detalhes/{$link}')\">Detalhes</button>"; }

            $packages .= "<div class=\"col-md-4\">
                            <div class=\"package\">
                            <center><img src=\"{$rs->package_IMAGE}\" alt=\"Rede Waze - Loja\" class=\"img-fluid\"></center>
                            <div class=\"title\">{$rs->package_NAME}</div>
                            <div class=\"price\">{$price}</div>
                            <div class=\"buttons\">
                                {$details}
                                <button class=\"btn btn-success add-to-cart\" id=\"{$rs->package_ID}-{$server}\">Adicionar no carrinho</button>
                            </div>
                        </div>
                        </div>";
        }
        return $packages."</div>";
    }

    public function description($str)
    {
        $str = explode("-", $str)[0];
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_packages` WHERE `package_ID`=?");
        $stmt->execute([$str]);
        if($stmt->rowCount() == 0) { return header("Location: /loja"); }
        $rs = $stmt->fetchObject();
        $price = "R$".number_format($rs->package_AMOUNT, 2, ',', '.');

        $server = $rs->package_SERVER;


        $description = "<div style=\"margin-top: -170px;\">
                            <div class=\"mb-3\"> 
                                <div class=\"col-md-6 mx-auto\">
                                    <div class=\"h1 text-center text-white\">Detalhes</div>
                                    <div class=\"h4 text-center text-white\">Confira oque vem neste produto</div>
                                </div>
                            </div>
                        </div>
                        <div class=\"container card cardshadow\">
                        <div class=\"content\">
                            <div class=\"row\">
                                <div class=\"col-md-4\">
                                    <div class=\"card p-3\">
                                        <center><img src=\"{$rs->package_IMAGE}\" alt=\"Rede Waze - Loja\" class=\"img-fluid mb-3\"></center>
                                        <h5>{$rs->package_NAME}</h5>
                                        <button class=\"btn btn-success full-width add-to-cart\" id=\"{$rs->package_ID}-{$server}\">{$price} <br><small style='font-size: 12px; font-weight: 600;'>ADICIONAR NO CARRINHO</small></button>
                                    </div>
                                </div>
                                <div class=\"col-md-8\">
                                    <div class=\"card p-3\">
                                        {$rs->package_DESCRIPTION}
                                    </div>
                                </div>
                            </div>
                        </div></div>";
        return $description;
    }

}