<?php


namespace app\api;

use app\lib\Config;
use app\lib\Json;
use app\lib\Model;
use app\lib\Security;
use PDO;

class Account
{

    private $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    public function auth()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security sistem']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        if(empty($_POST['username']) || empty($_POST['password'])) { return Json::response(['response' => 'error', 'message' => 'Informe seus dados']); }

        if($_POST['username'] == Config::ADMINUSER) {
            if($_POST['password'] != Config::ADMINPASS) { return Json::response(['response' => 'error', 'message' => 'Acesso negado']); }
            $_SESSION['WebAdminLogin'] = $_POST['username'];
            return Json::response(['response' => 'ok', 'message' => 'Redirecionando...']);
        }
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_accounts` WHERE `account_USERNAME`=? AND `account_PASSWORD`=?");
        $stmt->execute([$_POST['username'], md5($_POST['password'])]);
        if($stmt->rowCount() == 0) { return Json::response(['response' => 'error', 'message' => 'Acesso negado']); }
        $_SESSION['WebAdminLogin'] = $stmt->fetchObject()->account_ID;
        return Json::response(['response' => 'ok', 'message' => 'Redirecionando...']);
    }

    public function add()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security sistem']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        if(empty($_POST['username']) || empty($_POST['password']) || empty($_POST['permissions'])) { return Json::response(['response' => 'error', 'message' => 'Insira todos os dados']); }
        $stmt = $this->model->getConnection()->prepare("INSERT INTO `website_accounts`(`account_USERNAME`, `account_PASSWORD`, `account_PERMISSIONS`) VALUES (?, ?, ?)");
        $stmt->execute([$_POST['username'], md5($_POST['password']), $_POST['permissions']]);
        return Json::response(['response' => 'ok', 'message' => 'Usuário registrado com sucesso']);
    }

    public function count()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_accounts`");
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function listAll()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_accounts` ORDER BY `account_ID` DESC");
        $stmt->execute();
        if($stmt->rowCount() == 0) { return "<h5 class='text-muted' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%)'>Não há usuários</h5>"; }
        $fetch = $stmt->fetchAll(PDO::FETCH_OBJ);
        $packages = "";
        foreach ($fetch as $rs) {

            $commands = explode(";", $rs->account_PERMISSIONS);
            $command  = "";
            foreach ($commands as $r) {
                $command.="$r <br>";
            }
            $packages .= "<div class=\"package package-{$rs->account_ID}\">
                            <div class=\"row\">
                                <div class=\"col-md-8\">
                                    <div class=\"server\">
                                        {$rs->account_USERNAME}
                                    </div>
                                </div>
                                <div class=\"col-md-4\">
                                    <button class=\"tr-modal-open\" id=\"{$rs->account_ID}\">detalhes</button>
                                </div>
                            </div>
                        </div>
                        <div class=\"tr-modal tr-open-{$rs->account_ID}\">
                            <div class=\"tr-title\">
                                Dados da conta
                            </div>
                            <button class=\"tr-close\">
                                <i class=\"ion-ios-close-empty\"></i>
                            </button>
                            <br>
                            <div class=\"tr-body\">
                                <p>
                                    Nome:
                                    <span class=\"float-right\">{$rs->account_USERNAME}</span>
                                </p>
                                <p>
                                    Permissões:
                                    <small class=\"float-right\">
                                        {$command}
                                    </small>
                                </p>
                                <br>
                                <p>
                                    Deletar?
                                    <a href=\"javascript:void(0)\" class=\"float-right del-acc\" style=\"color: red\" id=\"{$rs->account_ID}\">
                                        Sim
                                    </a>
                                </p>
                            </div>
                        </div>";
        }
        return $packages;
    }

    public function delete()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security sistem']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        $stmt = $this->model->getConnection()->prepare("DELETE FROM `website_accounts` WHERE `account_ID`=?");
        $stmt->execute([$_POST['id']]);
    }

    public function hasPermission($permission)
    {
        if($_SESSION['WebAdminLogin'] == Config::ADMINUSER) { return true; }
        $id   = $_SESSION['WebAdminLogin'];
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_accounts` WHERE `account_ID` = ? AND `account_PERMISSIONS` LIKE '%$permission%'");
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }

}