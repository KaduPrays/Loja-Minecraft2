<?php

namespace app\api;

use app\lib\Json;
use app\lib\Model;
use app\lib\Security;

class Servers
{

    private $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    public function add()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        if(empty($_POST['name'])) { return Json::response(['response' => 'error', 'message' => 'Informe o nome do servidor']); }

        $stmt = $this->model->getConnection()->prepare("INSERT INTO `website_servers`(`server_NAME`) VALUES (?)");
        $stmt->execute([$_POST['name']]);

        return Json::response(['response' => 'ok', 'message' => 'Servidor adicionado com sucesso']);
    }

    public function delete()
    {
        if(!Security::connection()) { return Json::response(['response' => 'error', 'message' => 'You\'re blocked by security system']); }
        if(!isset($_POST)) { return Json::response(['response' => 'error', 'message' => 'No method submitted']); }
        if(empty($_POST['id'])) { return Json::response(['response' => 'error', 'message' => 'ID not sent']); }

        $stmt = $this->model->getConnection()->prepare("DELETE FROM `website_servers` WHERE `server_ID`=?");
        $stmt->execute([$_POST['id']]);

        return Json::response(['response' => 'ok']);
    }

    public function listAll()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_servers` WHERE `server_ID` != '0' ORDER BY `server_ID` DESC");
        $stmt->execute();
        if($stmt->rowCount() == 0) { return "<h5 class='text-muted' style='position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%)'>Não há servidores</h5>"; }
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $servers = "";
        foreach ($fetch as $rs) {
            $servers .= "<div class=\"package package-{$rs->server_ID}\">
                            <div class=\"row\">
                                <div class=\"col-md-5\">
                                    <div class=\"name\">
                                        {$rs->server_NAME}
                                    </div>
                                </div>
                                <div class=\"col-md-3\">
                                    <div class=\"server\">
                                        {$rs->server_ID}
                                    </div>
                                </div>
                                <div class=\"col-md-4\">
                                    <button class=\"tr-modal-open\" id=\"{$rs->server_ID}\">detalhes</button>
                                </div>
                            </div>
                        </div>
                        <div class=\"tr-modal tr-open-{$rs->server_ID}\">
                            <div class=\"tr-title\">
                                Dados do servidor
                            </div>
                            <button class=\"tr-close\">
                                <i class=\"ion-ios-close-empty\"></i>
                            </button>
                            <br>
                            <div class=\"tr-body\">
                                <p>
                                    Nome:
                                    <span class=\"float-right\">{$rs->server_NAME}</span>
                                </p>
                                <p>
                                    ID do servidor:
                                    <span class=\"float-right\">{$rs->server_ID}</span>
                                </p>
                                <br>
                                <p>
                                    Deletar?
                                    <a href=\"javascript:void(0)\" class=\"float-right del-server\" style=\"color: red\" id=\"{$rs->server_ID}\">
                                        Sim
                                    </a>
                                </p>
                            </div>
                        </div>";
        }
        return $servers;
    }

    public function count()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_servers` WHERE `server_ID` != 0");
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function lis()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_servers` WHERE `server_ID` != 0");
        $stmt->execute();
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $servers = "";
        foreach ($fetch as $rs)
        {
            $servers .= "<li><a href=\"/loja?c={$rs->server_ID}\">{$rs->server_NAME}</a></li>";
        }
        return $servers;
    }

    public function options()
    {
        $stmt = $this->model->getConnection()->prepare("SELECT * FROM `website_servers`");
        $stmt->execute();
        $fetch = $stmt->fetchAll(\PDO::FETCH_OBJ);
        $servers = "";
        foreach ($fetch as $rs)
        {
            $servers .= "<option value='{$rs->server_ID}'>{$rs->server_NAME}</option>";
        }
        return $servers;
    }

}