<?php

namespace app\controller\site;

use app\api\Account;
use app\api\Admin;
use app\api\Changelog;
use app\api\Cupom;
use app\api\News;
use app\api\Online;
use app\api\Packages;
use app\api\Servers;
use app\api\Staff;
use app\lib\Controller;

class adminController extends Controller {

    public $admin, $online, $packages, $cupom, $news, $server, $account, $changelog, $staff;

    public function __construct() {
        parent::__construct();

        $this->admin      = new Admin();
        $this->online     = new Online();
        $this->packages   = new Packages();
        $this->cupom      = new Cupom();
        $this->news       = new News();
        $this->server     = new Servers();
        $this->account    = new Account();
        $this->changelog  = new Changelog();
        $this->staff      = new Staff();

        $this->setLayout('admin_layout');
        $this->setTitle("RedeFlat - Painel");
        $this->setDescription("");
        $this->setKeywords("");
    }

    public function index() {
        if(!$this->admin->isLogged()) {
            $this->setLayout("admin_login_layout");
            $this->view("login");
        }
        $this->view();
    }

    public function auth() {
        echo $this->account->auth();
        return;
    }

    public function logout() {
        echo $this->admin->logout();
        return;
    }

    public function servers() {
        if(!$this->admin->isLogged()) {
            $this->setLayout("admin_login_layout");
            $this->view("login");
        }
        $this->view("servers");
    }

    public function addServer() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->server->add();
        return;
    }

    public function delServer() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->server->delete();
        return;
    }

    public function cupons() {
        if(!$this->admin->isLogged()) {
            $this->setLayout("admin_login_layout");
            $this->view("login");
        }
        $this->view("cupons");
    }

    public function addCupom() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->cupom->add();
        return;
    }

    public function delCupom() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
       echo $this->cupom->delete();
       return;
    }

    public function noticias() {
        if(!$this->admin->isLogged()) {
            $this->setLayout("admin_login_layout");
            $this->view("login");
        }
        $this->view("noticias");
    }

    public function addNews() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->news->add();
        return;
    }

    public function delNews() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->news->delete();
        return;
    }

    public function packages() {
        if(!$this->admin->isLogged()) {
            $this->setLayout("admin_login_layout");
            $this->view("login");
        }
        $this->view("packages");
    }

    public function addPackage() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->packages->add();
        return;
    }

    public function delPackage() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->packages->delete();
        return;
    }

    public function changelog() {
        if(!$this->admin->isLogged()) {
            $this->setLayout("admin_login_layout");
            $this->view("login");
        }
        $this->view();
    }

    public function addChangelog() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->changelog->add();
        return;
    }

    public function delChangelog() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->changelog->delete();
        return;
    }

    public function editChangelog() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->changelog->edit();
        return;
    }

    public function contas() {
        if(!$this->admin->isLogged()) {
            $this->setLayout("admin_login_layout");
            $this->view("login");
        }
        $this->view("contas");
    }

    public function addAccount() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->account->add();
        return;
    }

    public function delAccount() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->account->delete();
        return;
    }

    public function equipe() {
        if(!$this->admin->isLogged()) {
            $this->setLayout("admin_login_layout");
            $this->view("login");
        }
        $this->view();
    }

    public function addStaff() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->staff->add();
        return;
    }
    public function delStaff() {
        if(!$this->admin->isLogged())
        {
            header('Location: /admin');
            return;
        }
        echo $this->staff->delete();
        return;
    }

    public function transacoes() {
        if(!$this->admin->isLogged()) {
            $this->setLayout("admin_login_layout");
            $this->view("login");
        }
        $this->view();
    }

}