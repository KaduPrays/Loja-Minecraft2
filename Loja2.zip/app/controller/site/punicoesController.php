<?php

namespace app\controller\site;

use app\api\Online;
use app\api\Punish;
use app\lib\Controller;
use app\lib\Forms;

class punicoesController extends Controller {

    public $punish, $forms, $tokenID, $tokenVALUE, $inputs;

    public function __construct() {
        parent::__construct();

        $this->online   = new Online();
        $this->punish   = new Punish();
        $this->forms = new Forms();

        $this->setLayout('_layout');
        $this->setTitle("RedeFlat - Punições");
        $this->setDescription("");
        $this->setKeywords("");
    }

    public function index()
    {
        $this->tokenID    = $this->forms->getTokenID();
        $this->tokenVALUE = $this->forms->getToken();
        $this->inputs     = $this->forms->formNames(['search'], false);
        $this->view();
    }
}