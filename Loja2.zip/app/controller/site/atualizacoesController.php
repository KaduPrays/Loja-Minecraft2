<?php

namespace app\controller\site;

use app\api\Cart;
use app\api\Changelog;
use app\api\News;
use app\api\Online;
use app\lib\Controller;

class atualizacoesController extends Controller {

    public $online, $changelog;

    public function __construct() {
        parent::__construct();

        $this->online = new Online();
        $this->changelog = new Changelog();

        $this->setLayout('_layout');
        $this->setTitle("RedeFlat - Atualizações");
        $this->setDescription("");
        $this->setKeywords("");
    }

    public function index() {
        $this->view();
    }

}