<?php

namespace app\controller\site;

use app\api\Cart;
use app\api\News;
use app\api\Online;
use app\api\Staff;
use app\lib\Controller;

class equipeController extends Controller {

    public $online, $staff;

    public function __construct() {
        parent::__construct();

        $this->online = new Online();
        $this->staff  = new Staff();

        $this->setLayout('_layout');
        $this->setTitle("RedeFlat - Equipe");
        $this->setDescription("");
        $this->setKeywords("");
    }

    public function index() {
        $this->view();
    }

}