<?php

namespace app\controller\site;

use app\api\Cart;
use app\api\News;
use app\api\Online;
use app\lib\Controller;

class homeController extends Controller {

    public $online, $news, $cart;

    public function __construct() {
        parent::__construct();

        $this->online = new Online();
        $this->news   = new News();
        $this->cart   = new Cart();

        $this->setLayout('_layout');
        $this->setTitle("RedeFlat - Início");
        $this->setDescription("");
        $this->setKeywords("");
    }

    public function index() {
        $this->view();
    }

    public function get() {
        $this->removeLayout();
        $this->view("get");
    }

    public function noticia() {
        $this->view("noticia");
    }
}