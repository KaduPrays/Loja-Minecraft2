<?php

namespace app\controller\site;

use app\api\Cart;
use app\api\Checkout;
use app\api\Cupom;
use app\api\Online;
use app\api\Packages;
use app\api\Servers;
use app\lib\Controller;
use app\api\Profile;

class lojaController extends Controller {

    public $online, $server, $package, $cart, $checkout, $cupom, $profile;

    public function __construct() {
        parent::__construct();

        $this->online   = new Online();
        $this->server   = new Servers();
        $this->package  = new Packages();
        $this->cart     = new Cart();
        $this->checkout = new Checkout();
        $this->cupom    = new Cupom();
        $this->profile    = new Profile();

        $this->setLayout('_layout');
        $this->setTitle("RedeFlat - Loja");
        $this->setDescription("");
        $this->setKeywords("");
    }

    public function index() {
        if(!$this->profile->isLogged())
        {
            $this->view("login");
            return;
        }
        $this->view();
    }

    public function detalhes() {
        if(!$this->profile->isLogged())
        {
            $this->view("login");
            return;
        }
        $this->view("detalhes");
    }

    public function carrinho() {
        if(!$this->profile->isLogged())
        {
            $this->view("login");
            return;
        }
        $this->view("carrinho");
    }

    public function addCart() {
        if(!$this->profile->isLogged())
        {
            $this->view("login");
            return;
        }
        echo $this->cart->add();
        return;
    }

    public function removeCart() {
        if(!$this->profile->isLogged())
        {
            $this->view("login");
            return;
        }
        echo $this->cart->remove();
        return;
    }

    public function addDiscount() {
        if(!$this->profile->isLogged())
        {
            $this->view("login");
            return;
        }
        echo $this->cupom->run($_POST['hash']);
        return;
    }

    public function checkout() {
        if(!$this->profile->isLogged())
        {
            $this->view("login");
            return;
        }
        echo $this->checkout->run();
        return;
    }

    public function notification() {
        if(!$this->profile->isLogged())
        {
            $this->view("login");
            return;
        }
        echo $this->checkout->receive();
        return;
    }

    public function dopaypal() {
        $paypal = new \app\api\PayPal();
        $paypal->AuthorizationCheckout(APP_ROOT."loja/notification", $_GET['token'], $_GET['PayerID']);
        header("Location: /");
        return;
    }
    
    public function auth() {
        $this->removeLayout();
        echo $this->profile->login();
    }

    public function logout() {
        $this->removeLayout();
        $this->profile->logout();
        header("Location: /loja");
        return;
    }
    
}