$(function() {

    var util = "";

	$('#auth').on('submit', function(e) {
        e ? e.preventDefault() : false;
		$('.alert').slideUp("slow");
		$('#auth button').html("Autenticando...")
        $.ajax({
            url: util + "/admin/auth",
            type: "POST",
            dataType:'JSON',
            data: $(this).serialize(),
            complete: function (result){
                var r = JSON.parse(result.responseText);
                console.log(result.responseText);
                if(r.response == "ok"){
                    $('.alert-success').slideDown().html(r.message);
                    $('#auth input').prop('disabled', true);
                    setInterval(function () {
                        location.reload();
                    }, 2000);
                    $('#auth button').html("Redirecionando...");
                }else{
                    $('.alert-danger').slideDown().html(r.message);
                    $('#auth button').html("Entrar");
                }
            }
        });
        return false;
	});

    $('#addPackage').on('submit', function(e) {
		e ? e.preventDefault() : false;
        $('#addPackage .btn-success').html("Aguarde...");
        $.ajax({
            type: 'POST',
            url: util + "/admin/addPackage",
            data: $(this).serialize(),
            dataType: 'JSON',
            complete: function (result) {
                var r = JSON.parse(result.responseText);
                console.log(result.responseText);
                if(r.response == "ok"){
                	img = "/app/content/assets/images/admin/no-image.png";
                    $('.img-upload').html("<img src=\""+img+"\" class=\"img-fluid\">");
                    $('#addPackage .alert-success').slideDown().html(r.message);
                    $('#addPackage input').val("");
                    $('#addPackage .btn-success').html("Atualizando...");
                    setTimeout(function() {
                    	location.reload();
					}, 1500);
                }else{
                    $('#addPackage .alert-danger').slideDown().html(r.message);
                    $('#addPackage .btn-success').html("Tentar novamente");
                }
            }
        });
        return false;
    });

    $('.del-package').on('click', function(e) {
        e ? e.preventDefault() : false;
        var id = $(this).attr('id');
        $.ajax({
            type: 'POST',
            url: util + "/admin/delPackage",
            data: { 'id': id },
            complete: function () {
				var $class = ".package-" + id;
                var $close = ".tr-open-" + id;
				$($class).hide();
				$($close).fadeOut();
            }
        });
        return false;
	});

    $('#addServer').on('submit', function(e) {
        e ? e.preventDefault() : false;
        $('#addServer .btn-success').html("Aguarde...");
        $.ajax({
            type: 'POST',
            url: util + "/admin/addServer",
            data: $(this).serialize(),
            dataType: 'JSON',
            complete: function (result) {
                var r = JSON.parse(result.responseText);
                console.log(result.responseText);
                if(r.response == "ok"){
                    $('#addServer input').val("");
                    $('#addServer .btn-success').html("Atualizando...");
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                }else{
                    $('#addServer .alert-danger').slideDown().html(r.message);
                    $('#addServer .btn-success').html("Tentar novamente");
                }
            }
        });
        return false;
    });

    $('.del-server').on('click', function(e) {
        e ? e.preventDefault() : false;
        var id = $(this).attr('id');
        $.ajax({
            type: 'POST',
            url: util + "/admin/delServer",
            data: { 'id': id },
            complete: function () {
                var $class = ".package-" + id;
                var $close = ".tr-open-" + id;
                $($class).hide();
                $($close).fadeOut();
            }
        });
        return false;
    });

    $('#addCupom').on('submit', function(e) {
        e ? e.preventDefault() : false;
        $('#addCupom .btn-success').html("Aguarde...");
        $.ajax({
            type: 'POST',
            url: util + "/admin/addCupom",
            data: $(this).serialize(),
            dataType: 'JSON',
            complete: function (result) {
                var r = JSON.parse(result.responseText);
                console.log(result.responseText);
                if(r.response == "ok"){
                    $('#addCupom .alert-success').slideDown().html(r.message);
                    $('#addCupom input').val("");
                    $('#addCupom .btn-success').html("Atualizando...");
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                }else{
                    $('#addCupom .alert-danger').slideDown().html(r.message);
                    $('#addCupom .btn-success').html("Tentar novamente");
                }
            }
        });
        return false;
    });

    $('.del-cupom').on('click', function(e) {
        e ? e.preventDefault() : false;
        var id = $(this).attr('id');
        $.ajax({
            type: 'POST',
            url: util + "/admin/delCupom",
            data: { 'id': id },
            complete: function () {
                var $class = ".cupom-" + id;
                var $close = ".tr-open-" + id;
                $($class).hide();
                $($close).fadeOut();
            }
        });
        return false;
    });

    $('#addAccount').on('submit', function(e) {
        e ? e.preventDefault() : false;
        $('#addAccount .btn-success').html("Aguarde...");
        $.ajax({
            type: 'POST',
            url: util + "/admin/addAccount",
            data: $(this).serialize(),
            dataType: 'JSON',
            complete: function (result) {
                var r = JSON.parse(result.responseText);
                console.log(result.responseText);
                if(r.response == "ok"){
                    $('#addAccount .alert-success').slideDown().html(r.message);
                    $('#addAccount input').val("");
                    $('#addAccount .btn-success').html("Atualizando...");
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                }else{
                    $('#addAccount .alert-danger').slideDown().html(r.message);
                    $('#addAccount .btn-success').html("Tentar novamente");
                }
            }
        });
        return false;
    });

    $('.del-acc').on('click', function(e) {
        e ? e.preventDefault() : false;
        var id = $(this).attr('id');
        $.ajax({
            type: 'POST',
            url: util + "/admin/delAccount",
            data: { 'id': id },
            complete: function () {
                var $class = ".package-" + id;
                var $close = ".tr-open-" + id;
                $($class).hide();
                $($close).fadeOut();
            }
        });
        return false;
    });

    $('#addChangelog').on('submit', function(e) {
        e ? e.preventDefault() : false;
        $('.alert', this).slideUp();
        $('#addChangelog .btn-success').html("Aguarde...");
        $.ajax({
            type: 'POST',
            url: "/admin/addChangelog",
            data: $(this).serialize(),
            dataType: 'JSON',
            complete: function (result) {

                var r = JSON.parse(result.responseText);
                console.log(result.responseText);
                if(r.response == "ok"){
                    $('#addChangelog .alert-success').slideDown().html("Atualizando...");
                    $('#addChangelog input').val("");
                    $('#addChangelog .btn-success').html("Atualizando...");
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                }else{
                    $('#addChangelog .alert-danger').slideDown().html(r.message);
                    $('#addChangelog .btn-success').html("Tentar novamente");
                }
            }
        });
        return false;
    });

    $('.editChange').on('submit', function(e) {
        e ? e.preventDefault() : false;
        var button = $('.edit', this);
        button.html("...");
        $.ajax({
            type: 'POST',
            url: "/admin/editChangelog",
            data: $(this).serialize(),
            dataType: 'JSON',
            complete: function (result) {

                var r = JSON.parse(result.responseText);
                console.log(result.responseText);
                if(r.response == "ok"){
                    button.html("<i class='ion-checkmark'></i>");
                    setTimeout(function() {
                        button.html("<i class='ion-edit'></i>");
                    }, 1500);
                }
            }
        });
        return false;
    });

    $('.del-change').on('click', function(e) {
        e ? e.preventDefault() : false;
        var id = $(this).attr('id');
        $.ajax({
            type: 'POST',
            url: "/admin/delChangelog",
            data: { 'id': id },
            complete: function () {
                var $close = ".input-box-" + id;
                $($close).fadeOut();
            }
        });
        return false;
    });

    $('#addStaff').on('submit', function(e) {
        e ? e.preventDefault() : false;
        $('.alert', this).slideUp();
        $('#addStaff .btn-success').html("Aguarde...");
        $.ajax({
            type: 'POST',
            url: "/admin/addStaff",
            data: $(this).serialize(),
            dataType: 'JSON',
            complete: function (result) {

                var r = JSON.parse(result.responseText);
                console.log(result.responseText);
                if(r.response == "ok"){
                    $('#addStaff .alert-success').slideDown().html("Atualizando...");
                    $('#addStaff input').val("");
                    $('#addStaff .btn-success').html("Atualizando...");
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                }else{
                    $('#addStaff .alert-danger').slideDown().html(r.message);
                    $('#addStaff .btn-success').html("Tentar novamente");
                }
            }
        });
        return false;
    });

    $('.del-staff').on('click', function(e) {
        e ? e.preventDefault() : false;
        var id = $(this).attr('id');
        $.ajax({
            type: 'POST',
            url: "/admin/delStaff",
            data: { 'id': id },
            complete: function () {
                var $class = ".feed-" + id;
                var $close = ".tr-open-" + id;
                $($class).hide();
                $($close).fadeOut();
            }
        });
        return false;
    });

    $('#addFeed').on('submit', function(e) {
        e ? e.preventDefault() : false;
        $('.alert', this).slideUp();
        $('#addFeed .btn-success').html("Aguarde...");
        $.ajax({
            type: 'POST',
            url: util + "/admin/addNews",
            data: $(this).serialize(),
            dataType: 'JSON',
            complete: function (result) {
                var r = JSON.parse(result.responseText);
                console.log(result.responseText);
                if(r.response == "ok"){
                    $('#addFeed .alert-success').slideDown().html(r.message);
                    $('#addFeed input').val("");
                    $('#addFeed textarea').val("");
                    $('#addFeed .btn-success').html("Atualizando...");
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                }else{
                    $('#addFeed .alert-danger').slideDown().html(r.message);
                    $('#addFeed .btn-success').html("Tentar novamente");
                }
            }
        });
        return false;
    });

    $('.del-news').on('click', function(e) {
        e ? e.preventDefault() : false;
        var id = $(this).attr('id');
        $.ajax({
            type: 'POST',
            url: util + "/admin/delNews",
            data: { 'id': id },
            complete: function () {
                var $class = ".feed-" + id;
                var $close = ".tr-open-" + id;
                $($class).hide();
                $($close).fadeOut();
            }
        });
        return false;
    });

    $(".scroll-custom").niceScroll({
        cursorcolor: "rgba(189, 189, 189, .4)",
        cursorwidth: "6px",
        cursorborder: "none",
        smoothscroll: true
    });

    $('.summernote').summernote({
        tabsize: 2,
        height: 200,
        responsive: true,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul' ] ],
            [ 'insert', [ 'link', 'picture' ] ],
            [ 'view', [ 'fullscreen' ] ]
        ],
        lang: "pt-BR"
    });

    $("#imageUpload").on('change', function () {

    	img = $(this).val();
    	$('.img-upload').html("<img src=\""+img+"\" class=\"img-fluid\">");

    });

    $('#addInput').click(function(){
        var nome = 'commands[]';
        $("#multiples").append('<div class="form-group"> <input name="'+nome+'" class="form-control" placeholder="/command"></div>');
    });

    $('.table').DataTable({
        "language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Portuguese-Brasil.json"
        }
    });
});

$('.tr-modal-open').on('click', function() {
    var attr = $(this).attr('id');
    var str  = ".tr-open-" + attr;
    
    $(str).fadeIn("slow");
    
    var close = str + " .tr-close";

    $(close).on('click', function() {
        $(str).fadeOut("slow");
    });
});

function goTo(str) { return location.href = str }

(function(){
  "use strict";
		  var nb                = $(".dash-navbar-left"),
            nbBtnToggle       = $(".nb-btn-toggle"),
            nbBtnCollapse     = $(".nb-btn-collapse"),
            contentWrap        = $(".content-wrap"),
            contentWrapEffect  = contentWrap.data("effect"),
            windowHeight       = $(window).height() - 61,
            windowWidth        = $(window).width() < 767;
			function cwShowOverflow() {
				if ( windowWidth ) {
						contentWrap.css({
						height : windowHeight ,
						overflow : 'hidden'
					});
					$( 'html, body' ).css( 'overflow', 'hidden' );
				}
			}
			function cwHideOverflow() {
				if ( windowWidth ) {
					contentWrap.css({
						height : 'auto' ,
						overflow : 'auto'
					});
					$( 'html, body' ).css( 'overflow', 'auto' );
				}
			}
			function nbShow() {
				nb.addClass("nb-show").removeClass("nb-hide");
				contentWrap.addClass(contentWrapEffect);
				cwShowOverflow();
				nbBtnToggle.find("span").removeClass("fa-bars").addClass("fa-arrow-left");
			}

			function nbHide() {
				nb.removeClass("nb-show").addClass("nb-hide");
				contentWrap.removeClass(contentWrapEffect);
				cwHideOverflow();
				nbBtnToggle.find("span").removeClass("fa-arrow-left").addClass("fa-bars");
			}
			nb.addClass("nb-hide");
			nbBtnToggle.click( function() {
				if( nb.hasClass("nb-hide") ) {
					nbShow();
				} else {
					nbHide();
				}
			});
			nbBtnCollapse.click( function(e) {
				e.preventDefault();
				if( nb.hasClass("nb-collapsed") ) {
					nb.removeClass("nb-collapsed");
					contentWrap.removeClass("nb-collapsed");
					$(this).find(".nb-link-icon").removeClass("fa-arrow-right").addClass("fa-arrow-left");
				} else {
					nb.addClass("nb-collapsed");
					contentWrap.addClass("nb-collapsed");
					$(this).find(".nb-link-icon").removeClass("fa-arrow-left").addClass("fa-arrow-right");
				}
			});
			$( '.navbar-toggle' ).click( function() {
				if ( $( this ).hasClass( 'collapsed' ) ) {
					nbHide();
				}
			});
			nbBtnToggle.click( function() {
				$( '.navbar-toggle' ).addClass( 'collapsed' );
				$( '.navbar-collapse' ).removeClass( 'in' );
			});
			function isMobile() {
			  try { document.createEvent("TouchEvent"); return true; }
			  catch(e){ return false; }
			}
			if ( isMobile() == true ) {
				$(window).swipe( {
			    swipeRight:function() {
						nbShow();
						$( '.navbar-collapse' ).removeClass( 'in' );
			    },
			    swipeLeft:function() {
						nbHide();
			    },
			    threshold: 75
			  });
			}
			$( '.content-wrap' ).click( function() {
				nbHide();
			});
	  	$(".nb-nav > li > a").click( function() {
	  		$( document ).find( 'ul .in' ).collapse( 'hide' );
	  	});

})();